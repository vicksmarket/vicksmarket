'use server';
/**
 * @fileOverview الدماغ الذكي (Brain) لمتجر Vicks Market.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import { initializeFirebase } from '@/firebase';
import { collection, query, getDocs, limit, orderBy } from 'firebase/firestore';

const ChatInputSchema = z.object({
  message: z.string().describe('رسالة المستخدم'),
  userEmail: z.string().optional().describe('البريد الإلكتروني للمستخدم المسجل'),
  history: z.array(z.object({
    role: z.enum(['user', 'model']),
    text: z.string(),
  })).optional().describe('تاريخ المحادثة للحفاظ على السياق'),
});
export type ChatInput = z.infer<typeof ChatInputSchema>;

const ChatOutputSchema = z.object({
  response: z.string().describe('رد فيكس الذكي'),
});
export type ChatOutput = z.infer<typeof ChatOutputSchema>;

// البريد الرسمي للمالك الجديد
const ADMIN_EMAILS = ["vicksmarket@gmail.com"];

const searchProductsTool = ai.defineTool(
  {
    name: 'searchProducts',
    description: 'البحث عن المنتجات الحقيقية والأسعار في متجر فيكس ماركت حالياً.',
    inputSchema: z.object({
      searchTerm: z.string().describe('اسم المنتج أو الكلمة البحثية المراد العثور عليها'),
    }),
    outputSchema: z.array(z.any()),
  },
  async (input) => {
    const { firestore } = initializeFirebase();
    const productsRef = collection(firestore, 'products');
    
    const q = query(
      productsRef, 
      orderBy('isOriginal', 'desc'), 
      orderBy('createdAt', 'desc'), 
      limit(5)
    );
    
    const snapshot = await getDocs(q);
    const results = snapshot.docs.map(doc => ({
      name: doc.data().name,
      price: doc.data().price,
      category: doc.data().category,
      seller: doc.data().seller,
    }));

    return results.filter(p => p.name.toLowerCase().includes(input.searchTerm.toLowerCase()));
  }
);

export async function generalChat(input: ChatInput): Promise<ChatOutput> {
  const isAdmin = input.userEmail && ADMIN_EMAILS.includes(input.userEmail.toLowerCase());
  
  const { text } = await ai.generate({
    system: `أنت "فيكس"، الدماغ الذكي والمستشار المالي لمتجر "Vicks Market". 
    شخصيتك: تتحدث باللهجة المصرية الذكية والراقية. 
    لو السائل هو المدير (${ADMIN_EMAILS.join(', ')})، كن في خدمته المطلقة وناده بـ "يا باشا". 
    لو السائل عميل، كن أميناً معه وناده بـ "يا ملك". 
    شجع دائماً على الشراء بضمان فيكس.`,
    prompt: input.message,
    history: input.history?.map(h => ({ 
      role: h.role, 
      content: [{ text: h.text }] 
    })),
    tools: [searchProductsTool],
  });

  return { response: text || 'عذراً يا فندم، حصل هزة في الشبكة عندي، ممكن تعيد سؤالك يا ملك؟' };
}
