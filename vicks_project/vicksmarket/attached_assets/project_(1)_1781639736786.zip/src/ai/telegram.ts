
/**
 * @fileOverview بوت تليجرام الرسمي لتوثيق تجار فيكس ماركت.
 * يقوم بسحب رقم الهاتف وتفعيله في قاعدة البيانات فوراً.
 */

import TelegramBot from 'node-telegram-bot-api';
import { initializeFirebase } from '../firebase/index';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';

const token = process.env.TELEGRAM_BOT_TOKEN;

if (!token) {
  console.error("⚠️ خطأ: مفتاح بوت التليجرام غير موجود في ملف .env");
}

const bot = new TelegramBot(token || '', { polling: true });

// عند بدء المحادثة مع البوت
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  
  bot.sendMessage(chatId, "مرحباً بك في V Fix Market 🔧. لتوثيق حسابك كتاجر، اضغط على زر مشاركة رقم الهاتف بالأسفل 👇", {
    reply_markup: {
      keyboard: [[
        {
          text: "📲 مشاركة رقم الهاتف للتوثيق",
          request_contact: true 
        }
      ]],
      one_time_keyboard: true,
      resize_keyboard: true
    }
  });
});

// استقبال رقم الهاتف وإرساله للموقع لفتح الحساب
bot.on('contact', async (msg) => {
  const contact = msg.contact;
  if (!contact) return;
  
  const phoneNumber = contact.phone_number.replace(/\+/g, '');
  const chatId = msg.chat.id;
  
  console.log(`[Vicks Bot] تم استلام توثيق للرقم: ${phoneNumber}`);
  
  try {
    const { firestore } = initializeFirebase();
    // تسجيل التحقق في قاعدة البيانات لكي يشعر به الموقع في نفس اللحظة
    await setDoc(doc(firestore, "temp_verifications", phoneNumber), {
      verified: true,
      chatId: chatId,
      updatedAt: serverTimestamp()
    });
    
    bot.sendMessage(chatId, "✅ تم توثيق رقم هاتفك بنجاح! يمكنك العودة للموقع الآن لإكمال التسجيل. مبروك يا مدير!");
  } catch (error) {
    console.error("Telegram Bot Error:", error);
    bot.sendMessage(chatId, "⚠️ حدث خطأ أثناء التوثيق، يرجى المحاولة لاحقاً.");
  }
});

console.log("🚀 Telegram Bot is running and polling for updates...");
