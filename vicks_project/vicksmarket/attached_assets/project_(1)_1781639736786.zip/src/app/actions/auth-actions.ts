
'use server';

import nodemailer from 'nodemailer';

/**
 * @fileOverview Server Actions للتحقق عبر البريد والواتساب.
 */

// إرسال كود عبر البريد الإلكتروني
export async function sendOTPEmail(email: string, code: string, type: 'verification' | 'reset') {
  const user = process.env.GMAIL_USER;
  const pass = process.env.GMAIL_PASS;

  if (!user || !pass) {
    console.error("Email credentials are not configured in .env");
    return { success: false, error: "Email system not configured." };
  }

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: { user, pass }
  });

  const subject = type === 'verification' 
    ? 'كود التحقق الخاص بحسابك في فيكس ماركت' 
    : 'كود استعادة كلمة المرور - فيكس ماركت';

  const title = type === 'verification'
    ? 'مرحباً بك في V Fix Market'
    : 'استعادة الوصول لحسابك';

  const message = type === 'verification'
    ? 'شكراً لتسجيلك معنا. كود التحقق الخاص بك هو:'
    : 'لقد طلبت إعادة تعيين كلمة المرور. كود التحقق الخاص بك هو:';

  const mailOptions = {
    from: `"V Fix Market 🔧" <${user}>`,
    to: email,
    subject: subject,
    html: `
      <div style="font-family: 'Cairo', Arial, sans-serif; text-align: center; direction: rtl; padding: 40px; background-color: #f8f9fa;">
        <div style="max-width: 500px; margin: 0 auto; background-color: #ffffff; padding: 30px; border-radius: 40px; border-bottom: 8px solid #ff6600; box-shadow: 0 10px 30px rgba(0,0,0,0.05);">
          <h2 style="color: #ff6600; margin-bottom: 20px; font-weight: 900;">${title}</h2>
          <p style="color: #666; font-size: 16px; font-weight: bold;">${message}</p>
          <div style="background-color: #fff5eb; padding: 20px; font-size: 36px; font-weight: 900; letter-spacing: 10px; color: #ff6600; display: inline-block; margin: 25px 0; border-radius: 25px; border: 3px dashed #ff6600;">
            ${code}
          </div>
          <p style="color: #999; font-size: 11px; margin-top: 25px; line-height: 1.6;">هذا الكود صالح لمدة 10 دقائق فقط. لا تشارك هذا الكود مع أي أحد لحماية حسابك الملكي في فيكس ماركت.</p>
          <hr style="border: 0; border-top: 1px solid #eee; margin: 30px 0;" />
          <p style="color: #ccc; font-size: 10px; text-transform: uppercase; font-weight: 900; letter-spacing: 2px;">V Fix Market - Security Protocol v2.5</p>
        </div>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    return { success: true };
  } catch (error: any) {
    console.error("Error sending email:", error);
    return { success: false, error: error.message };
  }
}

// إرسال كود عبر الواتساب باستخدام UltraMsg
export async function sendWhatsAppOTP(phone: string, code: string) {
  const instanceId = process.env.ULTRAMSG_INSTANCE_ID || "175694";
  const token = process.env.ULTRAMSG_TOKEN;

  if (!token) {
    console.error("WhatsApp Token not configured in .env");
    return { success: false, error: "WhatsApp system not configured." };
  }

  // تنظيف الرقم ليكون بالتنسيق الدولي الصرف
  const cleanPhone = phone.replace(/\D/g, '');
  
  const url = `https://api.ultramsg.com/${instanceId}/messages/chat`;
  const bodyMessage = `*V Fix Market 🔧*\n\nأهلاً بك يا ملك! كود التحقق الخاص بك هو:\n\n*${code}*\n\nاستخدمه الآن لتفعيل حساب التاجر الموثق. هذا الكود صالح لمدة 10 دقائق فقط.`;

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        token: token,
        to: cleanPhone,
        body: bodyMessage,
        priority: '1'
      })
    });

    const data = await response.json();
    return { success: !!data.sent || data.sent === "true" };
  } catch (error: any) {
    console.error("Error sending WhatsApp:", error);
    return { success: false, error: error.message };
  }
}
