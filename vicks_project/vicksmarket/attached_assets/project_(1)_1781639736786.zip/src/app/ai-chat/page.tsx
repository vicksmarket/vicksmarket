"use client";

import React, { useState, useRef, useEffect } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Send, Loader2, Camera, Sparkles, Bot, User, Plus } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { VicksLogo } from "@/components/VicksLogo";
import { generalChat } from "@/ai/flows/general-chat";
import { VisualSearchDialog } from "@/components/VicksVisualSearch";
import { useUser } from "@/firebase";
import { cn } from "@/lib/utils";

const ADMIN_EMAILS = ["mom1113694362@gmail.com", "vicksmarket@gmail.com"];

export default function AIChatPage() {
  const router = useRouter();
  const { user } = useUser();
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  
  const isAdmin = user?.email && ADMIN_EMAILS.includes(user.email);
  const welcomeMsg = isAdmin 
    ? "أهلاً بك يا مدير في مركز قيادة VICKS AI. أنا رهن إشارتك، تحب نراجع إيه النهاردة؟" 
    : "أهلاً بك في VICKS AI! أنا مساعدك الشخصي، أقدر أبحثلك عن أي منتج أو أقولك السعر ده لقطة ولا لأ. تأمرني بإيه يا ملك؟";

  const [messages, setMessages] = useState([
    { role: "model" as const, text: welcomeMsg },
  ]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const handleSend = async () => {
    if (!message.trim() || loading) return;

    const userMessage = message.trim();
    const newMessages = [...messages, { role: "user" as const, text: userMessage }];
    setMessages(newMessages);
    setMessage("");
    setLoading(true);

    try {
      const history = messages.map(m => ({ 
        role: m.role === 'model' ? 'model' as const : 'user' as const, 
        text: m.text 
      }));
      
      const result = await generalChat({ 
        message: userMessage,
        userEmail: user?.email || undefined,
        history: history
      });
      
      setMessages((prev) => [...prev, { role: "model", text: result.response }]);
    } catch (error) {
      setMessages((prev) => [...prev, { role: "model", text: "يا غالي حصلت مشكلة في الشبكة، جرب تبعت تاني كدا." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-white dark:bg-[#1A2332] text-right font-cairo" dir="rtl">
      {/* Header */}
      <header className="flex items-center justify-between px-4 py-4 border-b shadow-sm sticky top-0 bg-white dark:bg-[#1A2332] z-50">
        <button 
          onClick={() => router.back()} 
          className="w-10 h-10 flex items-center justify-center bg-slate-50 dark:bg-slate-800 rounded-full"
        >
          <ArrowLeft className="w-5 h-5 rotate-180" />
        </button>
        <div className="flex items-center gap-2">
          <div className="flex flex-col items-end">
            <div className="flex items-center gap-1">
              <span className="font-black text-lg text-[#1A2332] dark:text-white uppercase leading-none">VICKS AI</span>
              <Sparkles className="w-3 h-3 text-orange-500 fill-orange-500" />
            </div>
            <span className="text-orange-500 text-[8px] font-bold">المستشار الذكي للمتجر</span>
          </div>
          <VicksLogo className="w-8 h-8" />
        </div>
      </header>

      {/* Chat Area */}
      <main className="flex-1 overflow-y-auto p-4 space-y-6 no-scrollbar relative bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] bg-fixed opacity-95">
        
        {/* Watermark Perfectly Centered with Colored Logo on the Left */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.08] dark:opacity-[0.04] select-none z-0">
          <div className="flex items-center gap-6">
            <span className="text-6xl font-black uppercase tracking-tighter">VICKS AI</span>
            <VicksLogo className="w-20 h-20" />
          </div>
        </div>

        <div className="relative z-10 space-y-6">
          {messages.map((msg, i) => (
            <div key={i} className={cn("flex", msg.role === 'model' ? "justify-start" : "justify-end", "animate-in fade-in slide-in-from-bottom-2 duration-300")}>
              <div className={cn(
                "relative max-w-[85%] p-4 rounded-[1.8rem] shadow-md",
                msg.role === 'model' 
                ? 'bg-white dark:bg-[#252D3D] rounded-tr-none text-slate-800 dark:text-white border-2 border-orange-50' 
                : 'bg-gradient-to-br from-orange-500 to-orange-600 text-white rounded-tl-none font-bold'
              )}>
                {msg.role === 'model' && (
                  <div className="absolute -top-3 -right-3 w-6 h-6 bg-slate-900 rounded-full flex items-center justify-center border-2 border-white">
                    <Bot className="w-3 h-3 text-orange-500" />
                  </div>
                )}
                {msg.role === 'user' && (
                  <div className="absolute -top-3 -left-3 w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center border-2 border-orange-500">
                    <User className="w-3 h-3 text-orange-600" />
                  </div>
                )}
                <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.text}</p>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex justify-start">
              <div className="bg-slate-50 dark:bg-[#252D3D] p-4 rounded-2xl rounded-tr-none flex items-center gap-3 border shadow-sm">
                <div className="flex gap-1">
                  <span className="w-1.5 h-1.5 bg-orange-500 rounded-full animate-bounce" />
                  <span className="w-1.5 h-1.5 bg-orange-500 rounded-full animate-bounce [animation-delay:0.2s]" />
                  <span className="w-1.5 h-1.5 bg-orange-500 rounded-full animate-bounce [animation-delay:0.4s]" />
                </div>
                <span className="text-[10px] font-black text-slate-400 uppercase">Vicks is thinking...</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Input Area */}
      <footer className="p-4 bg-white dark:bg-[#1A2332] border-t sticky bottom-0">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5">
            <VisualSearchDialog mode="upload">
              <Button variant="ghost" size="icon" title="رفع صورة" className="w-10 h-10 bg-slate-50 dark:bg-slate-800 rounded-full text-blue-500 hover:scale-110 transition-transform">
                <Plus className="w-5 h-5" />
              </Button>
            </VisualSearchDialog>
            <VisualSearchDialog mode="camera">
              <Button variant="ghost" size="icon" title="تصوير" className="w-10 h-10 bg-slate-50 dark:bg-slate-800 rounded-full text-orange-500 hover:scale-110 transition-transform">
                <Camera className="w-5 h-5" />
              </Button>
            </VisualSearchDialog>
          </div>
          
          <div className="flex-1 relative">
            <Input 
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="اسأل فيكس عن أي منتج..." 
              className="w-full h-12 rounded-full bg-slate-50 dark:bg-slate-800 border-2 border-orange-100 pr-5 pl-12 font-bold focus:border-orange-500 transition-all"
            />
            <Sparkles className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-orange-300 pointer-events-none" />
          </div>

          <Button 
            onClick={handleSend}
            disabled={!message.trim() || loading}
            className="w-12 h-12 bg-orange-500 hover:bg-orange-600 rounded-full p-0 text-white shadow-lg flex items-center justify-center transition-all active:scale-90"
          >
            <Send className="w-5 h-5 -rotate-45" />
          </Button>
        </div>
      </footer>
    </div>
  );
}
