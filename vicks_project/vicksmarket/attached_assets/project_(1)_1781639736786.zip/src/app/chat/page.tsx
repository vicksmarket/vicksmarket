"use client";

import React, { useMemo, useState, useEffect, useRef, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { 
  ArrowRight, User, MessageSquare, Send, Clock, Trash2, Ban, 
  ShieldAlert, Loader2, ShieldCheck, Zap
} from "lucide-react";
import { useUser, useFirestore, useCollection, useDoc } from "@/firebase";
import { 
  collection, query, where, orderBy, doc, addDoc, serverTimestamp, 
  updateDoc, setDoc, deleteDoc, getDocs 
} from "firebase/firestore";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

function ChatListContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const targetId = searchParams.get('id');
  
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  
  const [activeConv, setActiveConv] = useState<any>(null);
  const [msgText, setMsgText] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const convsQuery = useMemo(() => {
    if (!user) return null;
    return query(
      collection(db, "conversations"),
      where("participants", "array-contains", user.uid),
      orderBy("updatedAt", "desc")
    );
  }, [user, db]);

  const { data: convs, loading: convsLoading } = useCollection(convsQuery);

  useEffect(() => {
    if (targetId && user && convs && !convsLoading) {
      const existing = convs.find((c: any) => c.participants.includes(targetId));
      if (existing) {
        setActiveConv(existing);
      } else {
        const guestId = `Guest-${Math.floor(1000 + Math.random() * 9000)}`;
        const convId = [user.uid, targetId].sort().join('_');
        const newConv = {
          id: convId,
          participants: [user.uid, targetId],
          merchantId: targetId,
          customerId: user.uid,
          guestId: guestId,
          lastMessage: "بدأ محادثة سرية جديدة",
          updatedAt: serverTimestamp(),
          expiresAt: Date.now() + 24 * 60 * 60 * 1000
        };
        setDoc(doc(db, "conversations", convId), newConv);
        setActiveConv(newConv);
      }
    }
  }, [targetId, user, convs, convsLoading, db]);

  const messagesQuery = useMemo(() => {
    if (!activeConv) return null;
    return query(
      collection(db, "conversations", activeConv.id, "messages"),
      orderBy("createdAt", "asc")
    );
  }, [db, activeConv]);

  const { data: messages } = useCollection(messagesQuery);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!msgText.trim() || !activeConv || !user) return;
    const msgData = { text: msgText, senderId: user.uid, createdAt: serverTimestamp() };
    await addDoc(collection(db, "conversations", activeConv.id, "messages"), msgData);
    await updateDoc(doc(db, "conversations", activeConv.id), { lastMessage: msgText, updatedAt: serverTimestamp() });
    setMsgText("");
  };

  const handleDeleteChat = async () => {
    if (!activeConv) return;
    await deleteDoc(doc(db, "conversations", activeConv.id));
    setActiveConv(null);
    toast({ title: "تم حذف المحادثة نهائياً" });
  };

  const handleBlockUser = async () => {
    if (!activeConv || !user) return;
    const targetToBlock = activeConv.customerId === user.uid ? activeConv.merchantId : activeConv.customerId;
    await updateDoc(doc(db, "users", user.uid), {
      blockedUsers: (activeConv as any).blockedUsers ? [...(activeConv as any).blockedUsers, targetToBlock] : [targetToBlock]
    });
    await handleDeleteChat();
    toast({ variant: "destructive", title: "تم حظر المستخدم من مراسلتك" });
  };

  if (!user) return <div className="p-10 text-center font-black">يرجى تسجيل الدخول لمتابعة رسائلك السرية.</div>;

  return (
    <div className="flex flex-col h-full">
      <header className="p-4 bg-white dark:bg-[#1A2332] border-b shadow-sm flex items-center justify-between sticky top-0 z-50">
         <button onClick={() => activeConv ? setActiveConv(null) : router.back()} className="w-10 h-10 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center">
            <ArrowRight className="w-5 h-5" />
         </button>
         <div className="flex-1 text-center">
            {activeConv ? (
              <div className="flex flex-col">
                 <span className="text-sm font-black dark:text-white">{user.uid === activeConv.merchantId ? activeConv.guestId : "التاجر الموثق"}</span>
                 <span className="text-[8px] text-orange-500 font-bold uppercase tracking-widest">شات سري مؤقت</span>
              </div>
            ) : <h1 className="text-lg font-black dark:text-white">رسائل فيكس السرية</h1>}
         </div>
         <div className="flex gap-2">
            {activeConv && user.uid === activeConv.merchantId && (
              <>
                <button onClick={handleBlockUser} className="w-9 h-9 bg-red-50 text-red-500 rounded-full flex items-center justify-center hover:bg-red-100 transition-colors" title="حظر"><Ban className="w-4 h-4" /></button>
                <button onClick={handleDeleteChat} className="w-9 h-9 bg-slate-100 text-slate-500 rounded-full flex items-center justify-center hover:bg-red-50 hover:text-red-500 transition-colors" title="حذف"><Trash2 className="w-4 h-4" /></button>
              </>
            )}
            <div className="w-10" />
         </div>
      </header>

      <main className="flex-1 overflow-hidden flex flex-col">
        {!activeConv ? (
          <ScrollArea className="flex-1 p-4">
            <div className="bg-orange-50 dark:bg-orange-950/20 p-4 rounded-3xl border border-dashed border-orange-200 text-center mb-6">
               <p className="text-[10px] font-bold text-orange-600">المحادثات في فيكس "سرية" وتختفي تلقائياً بعد 24 ساعة.</p>
            </div>
            {convsLoading ? <div className="flex justify-center py-20"><Loader2 className="animate-spin text-orange-500" /></div> : !convs || convs.length === 0 ? <div className="flex flex-col items-center justify-center py-20 text-slate-300 gap-4"><MessageSquare className="w-16 h-16 opacity-20" /><p className="font-black text-sm">لا توجد صفقات جارية الآن.</p></div> : (
              <div className="space-y-3">
                {convs.map((c: any) => (
                  <div key={c.id} onClick={() => setActiveConv(c)} className="bg-white dark:bg-slate-800 p-4 rounded-[2rem] shadow-sm flex items-center gap-4 cursor-pointer hover:scale-[1.01] transition-all">
                    <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-700 flex items-center justify-center text-slate-400">{user.uid === c.merchantId ? <Zap className="w-6 h-6 text-orange-500" /> : <User className="w-6 h-6" />}</div>
                    <div className="flex-1 text-right">
                       <div className="flex items-center justify-between">
                          <span className="text-sm font-black dark:text-white">{user.uid === c.merchantId ? c.guestId : "محادثة مع تاجر"}</span>
                          <span className="text-[8px] text-slate-400 flex items-center gap-1"><Clock className="w-2.5 h-2.5" /> 24h</span>
                       </div>
                       <p className="text-[10px] text-slate-500 truncate mt-0.5">{c.lastMessage}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        ) : (
          <div className="flex flex-col h-full">
            <ScrollArea className="flex-1 p-6 space-y-6">
              <div className="flex flex-col gap-4">
                {messages?.map((m: any) => (
                  <div key={m.id} className={cn("flex", m.senderId === user.uid ? "justify-start" : "justify-end")}>
                    <div className={cn("max-w-[85%] p-4 rounded-[1.8rem] shadow-md transition-all", m.senderId === user.uid ? "bg-orange-500 text-white rounded-tr-none font-bold" : "bg-white dark:bg-slate-800 dark:text-white rounded-tl-none border-2 border-orange-50")}>
                      <p className="text-xs leading-relaxed">{m.text}</p>
                      <div className="mt-1 flex items-center gap-1 opacity-40 justify-end">
                         <span className="text-[7px] font-black">{m.createdAt?.toMillis ? new Date(m.createdAt.toMillis()).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }) : "..."}</span>
                      </div>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>
            <footer className="p-4 bg-white dark:bg-[#1A2332] border-t"><div className="flex gap-2 max-w-2xl mx-auto"><Input value={msgText} onChange={(e) => setMsgText(e.target.value)} placeholder="اكتب رسالتك السرية..." className="rounded-full h-12 pr-5 font-bold border-2 border-slate-100" onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()} /><Button onClick={handleSendMessage} disabled={!msgText.trim()} className="w-12 h-12 rounded-full bg-orange-500 p-0 text-white shadow-lg active:scale-90 transition-transform"><Send className="w-5 h-5 -rotate-45" /></Button></div></footer>
          </div>
        )}
      </main>
    </div>
  );
}

export default function ChatListPage() {
  return (
    <div className="flex flex-col h-screen bg-[#F8F9FA] dark:bg-[#1A2332] font-cairo" dir="rtl">
      <Suspense fallback={<div className="flex justify-center py-20"><Loader2 className="animate-spin text-orange-500" /></div>}>
        <ChatListContent />
      </Suspense>
    </div>
  );
}
