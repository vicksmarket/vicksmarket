
"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Mail, Key, Loader2, Timer, ExternalLink, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { VicksLogo } from "@/components/VicksLogo";
import { useAuth, useFirestore } from "@/firebase";
import { sendPasswordResetEmail } from "firebase/auth";
import { doc, setDoc, getDoc, deleteDoc, serverTimestamp } from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { sendOTPEmail } from "@/app/actions/auth-actions";

export default function ForgotPasswordPage() {
  const router = useRouter();
  const auth = useAuth();
  const db = useFirestore();
  const { toast } = useToast();

  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [isSent, setIsSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (timeLeft > 0) {
      timer = setInterval(() => setTimeLeft((prev) => prev - 1), 1000);
    }
    return () => clearInterval(timer);
  }, [timeLeft]);

  const handleSendOtp = async () => {
    if (!email) {
      toast({ variant: "destructive", title: "تنبيه", description: "يرجى إدخال البريد الإلكتروني أولاً." });
      return;
    }
    setLoading(true);
    try {
      const generatedOtp = Math.floor(100000 + Math.random() * 900000).toString();
      const expiresAt = Date.now() + 600000; // 10 minutes

      // 1. تسجيل الكود في الفايربيس للتحقق لاحقاً
      await setDoc(doc(db, "temp_resets", email), {
        code: generatedOtp,
        expiresAt: expiresAt,
        createdAt: serverTimestamp()
      });

      // 2. إرسال الإيميل الحقيقي عبر السيرفر
      const emailResult = await sendOTPEmail(email, generatedOtp, 'reset');
      
      if (emailResult.success) {
        setIsSent(true);
        setTimeLeft(60);
        setOtp(""); 
        toast({ title: "تم إرسال الكود!", description: `تفقد بريدك الآن، أرسلنا الكود لـ ${email}` });
        window.open("https://mail.google.com", "_blank");
      } else {
        toast({ variant: "destructive", title: "فشل الإرسال", description: "حصلت مشكلة في سيرفر الإرسال، حاول تاني." });
      }
      
    } catch (e: any) {
      toast({ variant: "destructive", title: "خطأ", description: "فشل إرسال الكود." });
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyAndReset = async () => {
    if (otp.length !== 6) {
      toast({ variant: "destructive", title: "كود ناقص", description: "أدخل الـ 6 أرقام كاملة." });
      return;
    }
    setLoading(true);
    try {
      const resetRef = doc(db, "temp_resets", email);
      const snap = await getDoc(resetRef);

      if (!snap.exists()) {
        toast({ variant: "destructive", title: "كود منتهي", description: "اطلب كوداً جديداً." });
        setIsSent(false);
        setLoading(false);
        return;
      }

      const data = snap.data();
      if (Date.now() > data.expiresAt) {
        await deleteDoc(resetRef);
        toast({ variant: "destructive", title: "انتهى الوقت", description: "انتهت صلاحية الكود (10 دقائق)." });
        setIsSent(false);
        setLoading(false);
        return;
      }

      if (data.code === otp) {
        await sendPasswordResetEmail(auth, email);
        await deleteDoc(resetRef);
        toast({ 
          title: "تم التحقق!", 
          description: "تم إرسال رابط رسمي لتغيير كلمة المرور لبريدك." 
        });
        setTimeout(() => router.push("/login"), 3000);
      } else {
        toast({ variant: "destructive", title: "كود خاطئ", description: "تأكد من الـ 6 أرقام التي أرسلناها." });
      }
    } catch (e: any) {
      toast({ variant: "destructive", title: "خطأ", description: "حدث خطأ أثناء التحقق." });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-[#1A2332] text-right font-cairo flex flex-col items-center justify-center p-6" dir="rtl">
      <div className="w-full max-w-md space-y-8">
        <header className="flex flex-col items-center gap-4 text-center">
          <VicksLogo className="w-16 h-16" />
          <h1 className="text-2xl font-black dark:text-white uppercase tracking-tight">استعادة كلمة المرور</h1>
          <p className="text-slate-400 text-xs font-bold">أدخل بريدك لنرسل لك كود التحقق (OTP)</p>
        </header>

        <main className="space-y-6">
          <div className="space-y-4">
            <div className="space-y-1.5">
              <div className="relative">
                <Mail className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-orange-500" />
                <Input 
                  type="email" 
                  value={email} 
                  onChange={(e) => setEmail(e.target.value)} 
                  placeholder="البريد الإلكتروني" 
                  disabled={isSent && timeLeft > 0}
                  className="h-14 rounded-2xl border-2 border-slate-100 pr-12 font-bold dark:bg-slate-900" 
                />
              </div>
            </div>

            {isSent && (
              <div className="space-y-4 animate-in fade-in slide-in-from-top-2 duration-300">
                <div className="relative">
                  <Key className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-orange-500" />
                  <Input 
                    type="text" 
                    maxLength={6} 
                    value={otp} 
                    onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))} 
                    placeholder="أدخل الكود المكون من 6 أرقام" 
                    className="h-16 rounded-2xl border-2 border-orange-500 pr-12 font-black text-center text-2xl tracking-[0.5rem] dark:bg-slate-900" 
                  />
                </div>
                
                <div className="flex items-center justify-between px-2">
                  <div className="flex items-center gap-2">
                    <Timer className={cn("w-4 h-4", timeLeft > 0 ? "text-orange-500 animate-pulse" : "text-red-500")} />
                    <span className={cn("text-xs font-black", timeLeft === 0 ? "text-red-500" : "text-orange-500")}>
                      {timeLeft > 0 ? `إعادة الإرسال بعد: ${timeLeft}ث` : "انتهى وقت الكود"}
                    </span>
                  </div>
                  <Button 
                    variant="link" 
                    size="sm"
                    onClick={() => window.open("https://mail.google.com", "_blank")}
                    className="text-xs font-black text-blue-500 flex items-center gap-1 p-0"
                  >
                    <ExternalLink className="w-3 h-3" /> فتح تطبيق Gmail
                  </Button>
                </div>
              </div>
            )}

            {!isSent ? (
              <Button 
                onClick={handleSendOtp} 
                disabled={loading}
                className="w-full h-14 bg-orange-500 hover:bg-orange-600 text-white text-lg font-black rounded-3xl shadow-xl"
              >
                {loading ? <Loader2 className="animate-spin" /> : "إرسال الكود وفتح Gmail"}
              </Button>
            ) : (
              <div className="space-y-3">
                <Button 
                  onClick={handleVerifyAndReset} 
                  disabled={loading || otp.length !== 6}
                  className="w-full h-14 bg-slate-900 hover:bg-black text-white text-lg font-black rounded-3xl shadow-xl"
                >
                  {loading ? <Loader2 className="animate-spin" /> : "تأكيد الكود وتغيير الباسورد"}
                </Button>
                
                {timeLeft === 0 && (
                  <Button 
                    variant="outline"
                    onClick={handleSendOtp}
                    className="w-full h-12 rounded-2xl border-2 border-orange-500 font-black text-orange-500 gap-2 hover:bg-orange-50 transition-colors"
                  >
                    <RotateCcw className="w-4 h-4" /> اضغط هنا لطلب كود جديد
                  </Button>
                )}
              </div>
            )}
          </div>
        </main>

        <footer className="text-center pt-4">
          <button onClick={() => router.push("/login")} className="flex items-center gap-2 text-slate-400 hover:text-orange-500 transition-colors mx-auto">
            <ArrowLeft className="w-4 h-4 rotate-180" />
            <span className="font-bold text-sm">رجوع لتسجيل الدخول</span>
          </button>
        </footer>
      </div>
    </div>
  );
}
