import './globals.css';
import { Toaster } from "@/components/ui/toaster";
import { FirebaseClientProvider } from "@/firebase/client-provider";
import { ViolationChecker } from "@/components/ViolationChecker";
import { FirebaseErrorListener } from "@/components/FirebaseErrorListener";
import { VicksAdminReturnButton } from "@/components/VicksAdminReturnButton";
import { ClientLayoutWrapper } from "@/components/ClientLayoutWrapper";

/**
 * @fileOverview الـ Layout الرئيسي كـ Server Component لضمان أعلى أداء واستقرار.
 */
export const metadata = {
  title: 'Vicks Market - فيكس ماركت',
  description: 'سوقك المفضل لبيع وشراء المنتجات بضمان فيكس',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet" />
        <meta name="theme-color" content="#FF6B00" />
      </head>
      <body className="font-cairo antialiased bg-[#F8F9FA] min-h-screen no-scrollbar">
        <FirebaseClientProvider>
          <ClientLayoutWrapper>
            <FirebaseErrorListener />
            <ViolationChecker />
            {children}
            <VicksAdminReturnButton />
            <Toaster />
          </ClientLayoutWrapper>
        </FirebaseClientProvider>
      </body>
    </html>
  );
}
