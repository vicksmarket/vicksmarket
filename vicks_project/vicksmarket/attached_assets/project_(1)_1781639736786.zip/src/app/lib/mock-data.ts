
export const MOCK_MERCHANTS = [
  {
    uid: "mock-merchant-1",
    fullName: "أحمد المنسي",
    shopName: "المنسي ستور للأجهزة",
    photoURL: "https://picsum.photos/seed/m1/400/400",
    isVerified: true,
    verificationType: "gold",
    unique_id: "100001",
    phone: "201113694362",
    email: "ahmed@vicks.com",
    location: "القاهرة",
    rating: 4.9,
    telegram: "elmansi_store"
  },
  {
    uid: "mock-merchant-2",
    fullName: "سارة محمد",
    shopName: "بيوتي سنتر سارة",
    photoURL: "https://picsum.photos/seed/m2/400/400",
    isVerified: true,
    verificationType: "blue",
    unique_id: "100002",
    phone: "201064782990",
    email: "sara@vicks.com",
    location: "الإسكندرية",
    rating: 4.7,
    telegram: null
  },
  {
    uid: "mock-merchant-car",
    fullName: "كابتن هيثم",
    shopName: "أوتو فيكس للمستعمل",
    photoURL: "https://picsum.photos/seed/m3/400/400",
    isVerified: true,
    verificationType: "gold",
    unique_id: "100003",
    phone: "201113694362",
    email: "haytham@vicks.com",
    location: "التجمع الخامس",
    rating: 5.0,
    telegram: "autovicks"
  }
];

export const MOCK_STORIES = [
  {
    id: "s1",
    sellerId: "mock-merchant-1",
    seller: "المنسي ستور",
    sellerImage: "https://picsum.photos/seed/m1/400/400",
    image: "https://picsum.photos/seed/s1/1080/1920",
    isGold: true,
    phone: "201113694362",
    telegram: "elmansi_store"
  },
  {
    id: "s2",
    sellerId: "mock-merchant-2",
    seller: "سارة محمد",
    sellerImage: "https://picsum.photos/seed/m2/400/400",
    image: "https://picsum.photos/seed/s2/1080/1920",
    isGold: false,
    phone: "201064782990",
    telegram: null
  },
  {
    id: "s3",
    sellerId: "mock-merchant-car",
    seller: "أوتو فيكس",
    sellerImage: "https://picsum.photos/seed/m3/400/400",
    image: "https://picsum.photos/seed/s3/1080/1920",
    isGold: true,
    phone: "201113694362",
    telegram: "autovicks"
  },
  {
    id: "s4",
    sellerId: "mock-merchant-1",
    seller: "المنسي ستور",
    sellerImage: "https://picsum.photos/seed/m1/400/400",
    image: "https://picsum.photos/seed/s4/1080/1920",
    isGold: true,
    phone: "201113694362",
    telegram: "elmansi_store"
  }
];

export const MOCK_PRODUCTS = [
  {
    id: "mock-1",
    name: "آيفون 15 برو ماكس - كسر زيرو",
    price: 55000,
    category: "إلكترونيات",
    description: "جهاز حالة ممتازة، مساحة 256 جيجا، لون تيتانيوم طبيعي. معاه الكرتونة وكافة الملحقات الأصلية.",
    image: "https://picsum.photos/seed/iphone15/600/600",
    seller: "أحمد المنسي",
    sellerId: "mock-merchant-1",
    location: "القاهرة",
    isOriginal: true,
    views: 1250,
    createdAt: new Date().toISOString(),
    telegram: "elmansi_store"
  },
  {
    id: "mock-2",
    name: "طقم حلل جرانيت كوري 10 قطع",
    price: 4200,
    category: "أدوات منزلية",
    description: "طقم أصلي غير قابل للالتصاق، يتحمل درجات الحرارة العالية، تصميم عصري وألوان جذابة.",
    image: "https://picsum.photos/seed/cookware/600/600",
    seller: "أحمد المنسي",
    sellerId: "mock-merchant-1",
    location: "الجيزة",
    isOriginal: true,
    views: 850,
    createdAt: new Date().toISOString(),
    telegram: "elmansi_store"
  },
  {
    id: "mock-3",
    name: "بي إم دبليو الفئة الخامسة 2023",
    price: 3200000,
    category: "مستعمل",
    description: "فابريكا بالكامل، صيانة توكيل، عداد 15000 كم، الفئة الأعلى تجهيزاً.",
    image: "https://picsum.photos/seed/bmw/600/600",
    seller: "كابتن هيثم",
    sellerId: "mock-merchant-car",
    location: "التجمع الخامس",
    isOriginal: true,
    views: 4500,
    createdAt: new Date().toISOString(),
    telegram: "autovicks"
  }
];
