"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { ChevronRight, Loader2, Mail, Lock, Eye, EyeOff, ShieldAlert, Key } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { VicksLogo } from "@/components/VicksLogo";
import { useAuth, useFirestore } from "@/firebase";
import { 
  signInWithEmailAndPassword, 
  GoogleAuthProvider, 
  signInWithPopup, 
  setPersistence,
  browserLocalPersistence
} from "firebase/auth";
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";
import Link from "next/link";

const ADMIN_EMAILS = ["vicksmarket@gmail.com"];
const ADMIN_SECRET_PIN = "202320";

export default function LoginPage() {
  const router = useRouter();
  const auth = useAuth();
  const db = useFirestore();
  const { toast } = useToast();
  
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [step, setStep] = useState(1);
  const [adminPin, setAdminPin] = useState("");

  const handleLogin = async () => {
    if (!email || !password) return;
    setLoading(true);

    try {
      await setPersistence(auth, browserLocalPersistence);
      const userCredential = await signInWithEmailAndPassword(auth, email.toLowerCase().trim(), password);
      const user = userCredential.user;
      
      const isAdmin = ADMIN_EMAILS.includes(user.email?.toLowerCase() || "");

      if (isAdmin) {
        setStep(2);
      } else {
        router.push('/');
      }
    } catch (error: any) {
      toast({ variant: "destructive", title: "خطأ في الدخول", description: "تأكد من صحة البيانات." });
    } finally { setLoading(false); }
  };

  const handleAdminVerification = () => {
    if (adminPin === ADMIN_SECRET_PIN) {
      localStorage.setItem('vicks_admin_mode', 'active');
      toast({ title: "أهلاً بك يا مدير" });
      router.push('/merchant');
    } else {
      toast({ variant: "destructive", title: "PIN خاطئ" });
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-[#1A2332] text-right font-cairo flex flex-col items-center justify-center p-6" dir="rtl">
      <div className="w-full max-w-md space-y-8">
        <header className="flex flex-col items-center gap-4 text-center">
          <VicksLogo className="w-16 h-16" />
          <h1 className="text-2xl font-black dark:text-white uppercase tracking-tighter">V Fix Market</h1>
        </header>

        {step === 1 ? (
          <div className="space-y-4">
            <div className="relative">
              <Mail className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-orange-500" />
              <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="البريد الإلكتروني" className="h-14 rounded-2xl pr-12 font-bold dark:bg-slate-900" />
            </div>

            <div className="relative">
              <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-orange-500" />
              <Input type={showPassword ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="كلمة المرور" className="h-14 rounded-2xl pr-12 text-center font-bold dark:bg-slate-900" />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300">
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>

            <Button onClick={handleLogin} disabled={loading} className="w-full h-14 bg-orange-500 hover:bg-orange-600 text-white text-lg font-black rounded-3xl shadow-xl">
              {loading ? <Loader2 className="animate-spin" /> : "دخول مباشر"}
            </Button>
            
            <div className="text-center pt-4">
               <Link href="/register" className="text-orange-500 font-black">إنشاء حساب جديد</Link>
            </div>
          </div>
        ) : (
          <div className="space-y-6 animate-in zoom-in duration-300">
            <div className="text-center space-y-2">
              <ShieldAlert className="w-12 h-12 text-orange-500 mx-auto animate-pulse" />
              <h2 className="text-xl font-black">تحقق المالك</h2>
            </div>
            <Input type="password" maxLength={6} value={adminPin} onChange={(e) => setAdminPin(e.target.value)} placeholder="أدخل PIN الإدارة" className="h-20 rounded-3xl text-center text-4xl font-black dark:bg-black" />
            <Button onClick={handleAdminVerification} className="w-full h-16 bg-black text-white rounded-[2rem] font-black text-lg">تأكيد الدخول</Button>
          </div>
        )}
      </div>
    </div>
  );
}
