
"use client";

import React from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Sparkles, Heart, Crown, MapPin } from "lucide-react";
import { VicksHeader } from "@/components/VicksHeader";
import { VicksProductGrid } from "@/components/VicksProductGrid";

export default function MallOfArabiaPage() {
  const router = useRouter();

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#121212] font-cairo pb-24" dir="rtl">
      <VicksHeader />
      
      {/* Luxury Arabia Banner */}
      <header className="bg-gradient-to-br from-emerald-600 to-teal-800 text-white p-10 rounded-b-[4rem] shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-10 opacity-5 rotate-12">
           <Crown className="w-60 h-60" />
        </div>
        <button onClick={() => router.push('/')} className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center mb-8 hover:bg-white/20 transition-all">
           <ArrowLeft className="w-6 h-6 rotate-180" />
        </button>
        <div className="relative z-10 flex flex-col items-center text-center gap-4">
           <div className="w-28 h-28 bg-white/95 rounded-[2.5rem] flex items-center justify-center text-emerald-700 text-5xl font-black shadow-2xl backdrop-blur-sm border-4 border-white/50">
             🛍️
           </div>
           <div className="space-y-1">
             <h1 className="text-4xl font-black uppercase tracking-tighter italic">Mall of Arabia</h1>
             <div className="flex items-center justify-center gap-2 text-emerald-100">
                <MapPin className="w-3.5 h-3.5" />
                <span className="text-[10px] font-bold uppercase tracking-widest">السادس من أكتوبر • الوجهة الفاخرة</span>
             </div>
           </div>
        </div>
      </header>

      <main className="p-6 space-y-12">
        {/* Luxury Section */}
        <section className="space-y-6">
           <div className="flex items-center justify-between">
              <div className="flex items-center gap-3 border-r-4 border-emerald-500 pr-4">
                 <Sparkles className="w-6 h-6 text-emerald-500" />
                 <h2 className="text-2xl font-black dark:text-white uppercase tracking-tighter">أفخم بيوت الأزياء</h2>
              </div>
              <Heart className="w-6 h-6 text-slate-300" />
           </div>
           <VicksProductGrid category="ملابس" />
        </section>

        {/* Beauty Section */}
        <section className="space-y-6">
           <div className="flex items-center gap-3 border-r-4 border-pink-500 pr-4">
              <div className="w-10 h-10 bg-pink-100 rounded-full flex items-center justify-center text-pink-600">🌿</div>
              <h2 className="text-2xl font-black dark:text-white uppercase tracking-tighter">جمال وأناقة بلا حدود</h2>
           </div>
           <VicksProductGrid category="جمال وعناية" />
        </section>

        <section className="bg-slate-900 rounded-[3rem] p-10 text-white shadow-2xl relative overflow-hidden">
           <div className="absolute top-0 left-0 p-10 opacity-10">
              <Sparkles className="w-32 h-32" />
           </div>
           <div className="relative z-10 space-y-4">
              <h3 className="text-2xl font-black">تجربة الـ VIP في مول العرب</h3>
              <p className="text-sm font-bold opacity-70 leading-relaxed">
                استمتع بخدمة المساعد الشخصي (VICKS AI) للتوصية بأفضل البراندات المتاحة حالياً في المول بأسعار حصرية.
              </p>
           </div>
        </section>
      </main>
    </div>
  );
}
