
"use client";

import React from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Building, ShieldCheck, PieChart, Briefcase, Globe } from "lucide-react";
import { VicksHeader } from "@/components/VicksHeader";
import { VicksProductGrid } from "@/components/VicksProductGrid";

export default function CapitalMallPage() {
  const router = useRouter();

  return (
    <div className="min-h-screen bg-[#F0F2F5] dark:bg-[#0F172A] font-cairo pb-24" dir="rtl">
      <VicksHeader />
      
      {/* Corporate Capital Banner */}
      <header className="bg-white dark:bg-slate-900 p-12 border-b-8 border-orange-600 shadow-lg relative">
        <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/shattered-island.png')] opacity-5 pointer-events-none"></div>
        
        <button onClick={() => router.push('/')} className="relative z-10 w-12 h-12 bg-slate-100 dark:bg-slate-800 rounded-2xl flex items-center justify-center mb-10 shadow-sm">
           <ArrowLeft className="w-6 h-6 rotate-180" />
        </button>

        <div className="relative z-10 flex items-end justify-between">
           <div className="space-y-2">
             <div className="flex items-center gap-2 text-orange-600">
                <Building className="w-6 h-6" />
                <span className="text-xs font-black uppercase tracking-widest">The Business District</span>
             </div>
             <h1 className="text-5xl font-black uppercase tracking-tighter dark:text-white">Capital Mall</h1>
             <p className="text-slate-400 text-sm font-bold uppercase tracking-widest">مركز الأعمال والسيارات الفاخرة</p>
           </div>
           <div className="w-24 h-24 bg-orange-600 rounded-[2rem] flex items-center justify-center text-white text-4xl font-black shadow-2xl shadow-orange-600/40">
             🏢
           </div>
        </div>
      </header>

      <main className="p-6 space-y-10">
        {/* Stats Row */}
        <div className="grid grid-cols-3 gap-3">
           {[
             { icon: <PieChart className="w-4 h-4" />, label: 'Market Share' },
             { icon: <Briefcase className="w-4 h-4" />, label: 'Business Hub' },
             { icon: <Globe className="w-4 h-4" />, label: 'Global Brands' }
           ].map((item, i) => (
             <div key={i} className="bg-white dark:bg-slate-800 p-4 rounded-2xl shadow-sm flex flex-col items-center gap-1">
                <div className="text-orange-600">{item.icon}</div>
                <span className="text-[7px] font-black uppercase text-slate-400">{item.label}</span>
             </div>
           ))}
        </div>

        <section className="space-y-6">
           <div className="flex items-center justify-between">
              <div className="flex items-center gap-3 border-r-4 border-slate-900 dark:border-white pr-4">
                 <ShieldCheck className="w-6 h-6 text-slate-900 dark:text-white" />
                 <h2 className="text-2xl font-black dark:text-white uppercase tracking-tighter">معرض السيارات والمستعمل</h2>
              </div>
           </div>
           <VicksProductGrid category="مستعمل" />
        </section>

        <div className="bg-slate-900 dark:bg-black p-8 rounded-[3.5rem] text-white space-y-4 shadow-2xl">
           <h3 className="text-xl font-black">Capital Executive Services</h3>
           <p className="text-xs font-bold opacity-60 leading-relaxed">
             خدمات خاصة لرجال الأعمال، شحن مباشر لباب الشركة، وتأمين كامل على المقتنيات الثمينة بضمان المطور MOM.
           </p>
        </div>
      </main>
    </div>
  );
}
