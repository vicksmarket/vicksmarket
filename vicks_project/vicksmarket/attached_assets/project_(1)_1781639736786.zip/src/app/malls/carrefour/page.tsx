
"use client";

import React from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, ShoppingCart, Tag, Flame, Info } from "lucide-react";
import { VicksHeader } from "@/components/VicksHeader";
import { VicksProductGrid } from "@/components/VicksProductGrid";
import { Button } from "@/components/ui/button";

export default function CarrefourMallPage() {
  const router = useRouter();

  return (
    <div className="min-h-screen bg-blue-50/30 dark:bg-[#0A192F] font-cairo pb-24" dir="rtl">
      <VicksHeader />
      
      {/* Custom Carrefour Banner */}
      <header className="bg-blue-600 text-white p-8 rounded-b-[3rem] shadow-xl relative overflow-hidden">
        <div className="absolute top-0 left-0 p-10 opacity-10">
           <ShoppingCart className="w-40 h-40" />
        </div>
        <button onClick={() => router.push('/')} className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center mb-6">
           <ArrowLeft className="w-5 h-5 rotate-180" />
        </button>
        <div className="relative z-10 flex flex-col items-center text-center gap-2">
           <div className="w-24 h-24 bg-white rounded-3xl flex items-center justify-center text-blue-600 text-4xl font-black shadow-2xl mb-2">
             🛒
           </div>
           <h1 className="text-3xl font-black uppercase tracking-tighter">Carrefour Mall</h1>
           <p className="text-blue-100 text-xs font-bold uppercase tracking-widest">توفير أكثر.. سعادة أكثر لكل العيلة</p>
        </div>
      </header>

      <main className="p-4 space-y-8">
        {/* Flash Offers */}
        <section className="bg-white dark:bg-slate-800 p-6 rounded-[2.5rem] shadow-sm border-2 border-blue-100 dark:border-blue-900/30 flex items-center justify-between">
           <div className="space-y-1">
              <h2 className="text-xl font-black text-blue-600 flex items-center gap-2">
                <Flame className="w-5 h-5" /> عروض اللحظة
              </h2>
              <p className="text-[10px] font-bold text-slate-400 uppercase">قسم السوبر ماركت والمنظفات</p>
           </div>
           <Button className="bg-blue-600 hover:bg-blue-700 rounded-xl font-black">اكتشف الآن</Button>
        </section>

        {/* Categories inside Carrefour */}
        <div className="grid grid-cols-1 gap-6">
           <div className="space-y-4">
              <div className="flex items-center gap-2 border-r-4 border-blue-600 pr-3">
                 <Tag className="w-4 h-4 text-blue-600" />
                 <h3 className="font-black text-lg dark:text-white uppercase">منتجات كارفور الطازجة</h3>
              </div>
              <VicksProductGrid category="سوبر ماركت" />
           </div>

           <div className="space-y-4">
              <div className="flex items-center gap-2 border-r-4 border-orange-500 pr-3">
                 <Tag className="w-4 h-4 text-orange-500" />
                 <h3 className="font-black text-lg dark:text-white uppercase">أدوات منزلية (كارفور هوم)</h3>
              </div>
              <VicksProductGrid category="أدوات منزلية" />
           </div>
        </div>

        <div className="bg-blue-100 dark:bg-blue-950/30 p-4 rounded-2xl border border-blue-200 flex items-start gap-3">
           <Info className="w-5 h-5 text-blue-600 mt-0.5" />
           <p className="text-[10px] font-bold text-blue-800 dark:text-blue-300 leading-relaxed">
             جميع منتجات كارفور في هذا القسم تخضع لرقابة الجودة فيكس وتوفر لك نقاط مكافأة مضاعفة عند الشراء بضمان فيكس.
           </p>
        </div>
      </main>
    </div>
  );
}
