
"use client";

import React from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Sparkles, MapPin, Heart, History, Star } from "lucide-react";
import { VicksHeader } from "@/components/VicksHeader";
import { VicksProductGrid } from "@/components/VicksProductGrid";

export default function CleopatraMallPage() {
  const router = useRouter();

  return (
    <div className="min-h-screen bg-[#FFFBF0] dark:bg-[#1A1612] font-cairo pb-24" dir="rtl">
      <VicksHeader />
      
      {/* Classic Cleopatra Banner */}
      <header className="bg-[#8B5E3C] text-[#F5E6D3] p-12 rounded-b-[5rem] shadow-2xl relative overflow-hidden border-b-8 border-[#C5A059]">
        <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/egyptian-linen.png')] pointer-events-none"></div>
        <div className="absolute top-0 left-0 p-10 opacity-5">
           <History className="w-60 h-60" />
        </div>
        
        <button onClick={() => router.push('/')} className="relative z-10 w-12 h-12 bg-white/10 rounded-full flex items-center justify-center mb-8 border border-white/20">
           <ArrowLeft className="w-6 h-6 rotate-180" />
        </button>

        <div className="relative z-10 flex flex-col items-center gap-4">
           <div className="w-28 h-28 bg-[#C5A059] rounded-full flex items-center justify-center text-5xl shadow-2xl border-8 border-[#8B5E3C] relative">
             🏺
             <div className="absolute -top-2 -right-2 bg-white rounded-full p-1 shadow-lg">
                <Star className="w-6 h-6 text-[#C5A059] fill-current" />
             </div>
           </div>
           <div className="text-center space-y-1">
             <h1 className="text-4xl font-black uppercase tracking-widest text-[#F5E6D3]">Cleopatra Mall</h1>
             <p className="text-[10px] font-black uppercase tracking-[0.3rem] opacity-60">عراقة الماضي.. تسوق المستقبل</p>
           </div>
        </div>
      </header>

      <main className="p-6 space-y-12">
        <section className="space-y-6">
           <div className="flex items-center gap-3 border-r-4 border-[#C5A059] pr-4">
              <Sparkles className="w-6 h-6 text-[#C5A059]" />
              <h2 className="text-2xl font-black text-[#8B5E3C] dark:text-[#C5A059] uppercase tracking-tighter">منتجات العناية والجمال الملكية</h2>
           </div>
           <VicksProductGrid category="جمال وعناية" />
        </section>

        <section className="space-y-6">
           <div className="flex items-center gap-3 border-r-4 border-[#8B5E3C] pr-4">
              <div className="w-10 h-10 bg-[#8B5E3C] rounded-full flex items-center justify-center text-white">🏠</div>
              <h2 className="text-2xl font-black text-[#8B5E3C] dark:text-[#C5A059] uppercase tracking-tighter">أثاث وتحف منزلية فاخرة</h2>
           </div>
           <VicksProductGrid category="أدوات منزلية" />
        </section>

        <div className="p-10 bg-white dark:bg-slate-900 rounded-[4rem] shadow-xl border-t-8 border-[#C5A059] text-center space-y-4">
           <MapPin className="w-10 h-10 text-[#C5A059] mx-auto" />
           <h3 className="text-xl font-black text-[#8B5E3C] dark:text-[#C5A059]">موقع كليوباترا مول</h3>
           <p className="text-xs font-bold text-slate-500 dark:text-slate-400">
             المول يضم أكثر من 500 معرض متخصص في التحف، المجوهرات، والديكور الراقي بضمان فيكس ماركت الرسمي.
           </p>
        </div>
      </main>
    </div>
  );
}
