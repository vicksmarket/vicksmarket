
"use client";

import React from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Cpu, Zap, Radio, Terminal, Ghost } from "lucide-react";
import { VicksHeader } from "@/components/VicksHeader";
import { VicksProductGrid } from "@/components/VicksProductGrid";

export default function TitanMallPage() {
  const router = useRouter();

  return (
    <div className="min-h-screen bg-black font-cairo pb-24 text-white" dir="rtl">
      <VicksHeader />
      
      {/* Tech Titan Banner */}
      <header className="bg-[#1A1A1A] p-12 border-b-4 border-cyan-500 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20"></div>
        <div className="absolute -top-20 -right-20 w-80 h-80 bg-cyan-500/10 rounded-full blur-[100px]"></div>
        
        <button onClick={() => router.push('/')} className="relative z-10 w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center mb-8 border border-slate-700">
           <ArrowLeft className="w-5 h-5 rotate-180 text-cyan-400" />
        </button>

        <div className="relative z-10 flex flex-col items-center gap-6">
           <div className="w-24 h-24 bg-slate-900 border-2 border-cyan-500 rounded-3xl flex items-center justify-center text-5xl shadow-[0_0_30px_rgba(6,182,212,0.3)] animate-pulse">
             ⚡
           </div>
           <div className="text-center space-y-1">
             <h1 className="text-4xl font-black uppercase tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-600">Titan Mall</h1>
             <p className="text-[10px] font-black uppercase tracking-[0.5rem] text-cyan-500/60">The Future of Tech</p>
           </div>
        </div>
      </header>

      <main className="p-4 space-y-12">
        <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4">
           {['GEAR', 'GAMING', 'MOBILE', 'SETUP'].map(tag => (
             <div key={tag} className="px-6 py-2 bg-slate-900 border border-slate-800 rounded-full text-[10px] font-black text-cyan-500 shadow-lg whitespace-nowrap">
               # {tag}
             </div>
           ))}
        </div>

        <section className="space-y-6">
           <div className="flex items-center gap-3">
              <div className="w-1 h-8 bg-cyan-500 rounded-full"></div>
              <Cpu className="w-6 h-6 text-cyan-400" />
              <h2 className="text-2xl font-black uppercase tracking-tight">أقوى الأجهزة الذكية</h2>
           </div>
           <VicksProductGrid category="إلكترونيات" />
        </section>

        <section className="grid grid-cols-2 gap-4">
           <div className="bg-slate-900/50 p-8 rounded-[2.5rem] border border-slate-800 flex flex-col items-center text-center gap-3">
              <Radio className="w-8 h-8 text-blue-500" />
              <h3 className="font-black text-xs uppercase">5G Active Zone</h3>
           </div>
           <div className="bg-slate-900/50 p-8 rounded-[2.5rem] border border-slate-800 flex flex-col items-center text-center gap-3">
              <Terminal className="w-8 h-8 text-cyan-500" />
              <h3 className="font-black text-xs uppercase">AI Service Hub</h3>
           </div>
        </section>

        <div className="p-8 bg-gradient-to-r from-cyan-900/20 to-blue-900/20 rounded-[3rem] border-2 border-dashed border-cyan-500/30 flex items-center justify-between">
           <div className="space-y-1">
              <p className="font-black text-cyan-400">نظام فحص الهاردوير</p>
              <p className="text-[9px] opacity-60">كل الأجهزة هنا مضمونة 100% من فيكس</p>
           </div>
           <Ghost className="w-10 h-10 text-cyan-500/20" />
        </div>
      </main>
    </div>
  );
}
