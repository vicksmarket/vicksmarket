"use client";

import React, { useMemo } from "react";
import { useParams, useRouter } from "next/navigation";
import { 
  ArrowRight, Phone, Mail, MessageCircle, Send, 
  BadgeCheck, Star, ShieldCheck, ShoppingBag, Loader2, User, MapPin, Share2, Info
} from "lucide-react";
import { useFirestore, useDoc, useCollection } from "@/firebase";
import { doc, collection, query, where } from "firebase/firestore";
import { Button } from "@/components/ui/button";
import { VicksProductCard } from "@/components/VicksProductCard";
import { MOCK_MERCHANTS, MOCK_PRODUCTS } from "@/app/lib/mock-data";
import { cn } from "@/lib/utils";

export default function MerchantPublicProfilePage() {
  const params = useParams();
  const router = useRouter();
  const db = useFirestore();
  const id = params.id as string;

  // فحص إذا كان التاجر وهمياً للعرض
  const mockMerchant = useMemo(() => MOCK_MERCHANTS.find(m => m.uid === id), [id]);
  
  const merchantRef = useMemo(() => doc(db, "users", id), [db, id]);
  const { data: dbMerchant, loading: merchantLoading } = useDoc(id.startsWith('mock-') ? null : merchantRef);

  const merchant = mockMerchant || dbMerchant;

  const productsQuery = useMemo(() => query(
    collection(db, "products"),
    where("sellerId", "==", id)
  ), [db, id]);

  const { data: dbProducts, loading: productsLoading } = useCollection(id.startsWith('mock-') ? null : productsQuery);

  const products = id.startsWith('mock-') 
    ? MOCK_PRODUCTS.filter(p => p.sellerId === id)
    : dbProducts;

  if (merchantLoading && !mockMerchant) return <div className="min-h-screen flex items-center justify-center bg-white dark:bg-[#1A2332]"><Loader2 className="animate-spin text-orange-500 w-12 h-12" /></div>;
  if (!merchant) return <div className="min-h-screen flex items-center justify-center font-black text-slate-400 bg-white dark:bg-[#1A2332]">التاجر غير موجود في قاعدة بيانات فيكس يا ملك</div>;

  return (
    <div className="min-h-screen bg-[#F8F9FA] dark:bg-[#1A2332] font-cairo text-right pb-24" dir="rtl">
      
      {/* 1. Header with Banner and Floating Logo */}
      <header className="relative bg-white dark:bg-[#252D3D] shadow-md border-b-4 border-orange-500">
        
        {/* Banner (الغلاف) */}
        <div className="h-[140px] w-full bg-gradient-to-br from-slate-900 via-slate-800 to-orange-900 relative overflow-hidden">
           <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
           <button 
             onClick={() => router.back()} 
             className="absolute top-4 right-4 w-10 h-10 bg-black/30 backdrop-blur-md rounded-full flex items-center justify-center text-white z-20 hover:bg-black/50 transition-all"
           >
              <ArrowRight className="w-5 h-5" />
           </button>
           <button className="absolute top-4 left-4 w-10 h-10 bg-black/30 backdrop-blur-md rounded-full flex items-center justify-center text-white z-20">
              <Share2 className="w-4 h-4" />
           </button>
        </div>

        {/* Floating Profile Info Container */}
        <div className="relative px-6 pb-6 flex flex-col items-center">
           {/* Logo العائم */}
           <div className="relative -mt-14 mb-3">
              <div className="w-28 h-28 rounded-[2.5rem] bg-white dark:bg-[#1A2332] flex items-center justify-center overflow-hidden border-[6px] border-white dark:border-[#252D3D] shadow-2xl">
                 {merchant.photoURL ? (
                   <img src={merchant.photoURL} alt={merchant.fullName} className="w-full h-full object-cover" />
                 ) : (
                   <User className="w-12 h-12 text-slate-300" />
                 )}
              </div>
              {merchant.isVerified && (
                <div className="absolute bottom-1 right-0 bg-white dark:bg-slate-900 p-1 rounded-2xl shadow-xl border-2 border-orange-100">
                   <BadgeCheck className={cn("w-6 h-6", merchant.verificationType === 'gold' ? 'text-yellow-500' : 'text-blue-500')} />
                </div>
              )}
           </div>

           {/* Store Identity Block */}
           <div className="text-center space-y-1">
              <h1 className="text-2xl font-black dark:text-white uppercase tracking-tighter leading-none">
                {merchant.shopName || merchant.fullName}
              </h1>
              <div className="flex items-center justify-center gap-2 flex-wrap">
                 <div className="flex items-center gap-0.5 text-yellow-400">
                    <Star className="w-3.5 h-3.5 fill-current" />
                    <span className="text-xs font-black text-slate-500 dark:text-slate-400">{merchant.rating || 5.0}</span>
                 </div>
                 <span className="text-[10px] font-black text-orange-500 bg-orange-50 dark:bg-orange-950/30 px-3 py-0.5 rounded-full border border-orange-100">
                   ID: {merchant.unique_id}
                 </span>
              </div>
              <div className="flex items-center justify-center gap-1.5 text-slate-400 mt-1">
                <MapPin className="w-3 h-3 text-red-500" />
                <span className="text-[10px] font-bold">{merchant.location || "مركز فيكس الرئيسي"}</span>
              </div>
           </div>
        </div>

        {/* 2. Action Capsules (أزرار التواصل) */}
        <div className="px-6 pb-6 flex justify-center gap-2 overflow-x-auto no-scrollbar">
           <Button 
             onClick={() => window.open(`tel:${merchant.phone}`)} 
             className="h-10 px-5 bg-white dark:bg-slate-800 text-blue-600 border-2 border-slate-50 dark:border-slate-700 rounded-[20px] font-black text-[10px] gap-2 hover:bg-slate-50 active:scale-95 transition-all shadow-sm"
           >
             <Phone className="w-3.5 h-3.5" /> اتصال
           </Button>
           <Button 
             onClick={() => window.open(`https://wa.me/${merchant.phone?.replace(/\D/g, '')}`)} 
             className="h-10 px-5 bg-[#25D366] text-white rounded-[20px] font-black text-[10px] gap-2 hover:bg-[#1da853] active:scale-95 transition-all shadow-lg"
           >
             <MessageCircle className="w-3.5 h-3.5 fill-white" /> واتساب
           </Button>
           <Button 
             onClick={() => router.push(`/chat?id=${id}`)} 
             className="h-10 px-5 bg-orange-500 text-white rounded-[20px] font-black text-[10px] gap-2 hover:bg-orange-600 active:scale-95 transition-all shadow-lg"
           >
             <Send className="w-3.5 h-3.5 -rotate-45" /> شات سري
           </Button>
           <Button 
             onClick={() => window.open(`mailto:${merchant.email}`)} 
             className="h-10 px-5 bg-white dark:bg-slate-800 text-red-500 border-2 border-slate-50 dark:border-slate-700 rounded-[20px] font-black text-[10px] gap-2 hover:bg-slate-50 active:scale-95 transition-all shadow-sm"
           >
             <Mail className="w-3.5 h-3.5" /> بريد
           </Button>
        </div>
      </header>

      {/* 3. Product Gallery Title & Divider */}
      <div className="px-4 mt-8 mb-4">
         <div className="flex items-center gap-3">
            <div className="w-1.5 h-6 bg-orange-500 rounded-full"></div>
            <h2 className="text-lg font-black dark:text-white uppercase tracking-tight flex items-center gap-2">
               معرض المنتجات <ShoppingBag className="w-4 h-4 text-orange-500" />
            </h2>
         </div>
         <div className="h-px bg-slate-200 dark:bg-slate-800 w-full mt-3"></div>
      </div>

      {/* 4. Product Grid (ثنائي متلاصق) */}
      <main className="px-0">
         {productsLoading ? (
            <div className="flex justify-center py-20"><Loader2 className="animate-spin text-orange-500 w-12 h-12" /></div>
         ) : products && products.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-0">
               {products.map((p: any) => (
                 <div key={p.id} className="border-r border-b border-slate-100 dark:border-slate-800">
                    <VicksProductCard 
                      id={p.id}
                      name={p.name}
                      price={p.price.toString()}
                      image={p.image}
                      seller={merchant.shopName || merchant.fullName}
                      sellerId={id}
                      sellerImage={merchant.photoURL}
                      isVerified={merchant.isVerified}
                      isGold={merchant.verificationType === 'gold'}
                      description={p.description}
                      rating={p.rating}
                    />
                 </div>
               ))}
            </div>
         ) : (
            <div className="mx-6 text-center py-20 bg-white dark:bg-slate-800 rounded-[3rem] border-2 border-dashed border-slate-200 dark:border-slate-700">
               <div className="w-16 h-16 bg-slate-50 dark:bg-slate-900 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Info className="w-8 h-8 text-slate-300" />
               </div>
               <p className="font-black text-slate-400 text-sm">لا يوجد منتجات معروضة حالياً لهذا التاجر.</p>
               <Button onClick={() => router.push('/')} variant="link" className="text-orange-500 font-bold mt-2">استكشف منتجات أخرى</Button>
            </div>
         )}
      </main>
    </div>
  );
}
