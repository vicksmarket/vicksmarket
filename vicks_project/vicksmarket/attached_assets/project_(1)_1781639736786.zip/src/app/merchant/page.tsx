
"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { 
  LogOut, Home, Loader2, ShieldAlert, AlertCircle,
  Zap, Users, ShoppingCart, Search, Gavel, Wallet, ShieldCheck, Crown, UserCircle, Store, Clock, Info
} from "lucide-react";
import { VicksLogo } from "@/components/VicksLogo";
import { useUser, useFirestore, useAuth, useCollection } from "@/firebase";
import { doc, updateDoc, collection, query, where, increment, getDocs } from "firebase/firestore";
import { signOut } from "firebase/auth";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

const ADMIN_EMAILS = ["mom1113694362@gmail.com", "vicksmarket@gmail.com"];

export default function MerchantProfilePage() {
  const router = useRouter();
  const auth = useAuth();
  const db = useFirestore();
  const { user, loading: userLoading } = useUser();
  const { toast } = useToast();
  
  const [isAdminLocal, setIsAdminLocal] = useState(false);
  const [loadingAction, setLoadingAction] = useState(false);

  // States for management
  const [targetId, setTargetId] = useState("");
  const [pointsAmount, setPointsAmount] = useState("");
  const [verifType, setVerifType] = useState("blue");
  const [verifDuration, setVerifDuration] = useState("1m");
  const [banTime, setBanTime] = useState("1w");
  
  // Confirmation Modal
  const [confirmModal, setConfirmModal] = useState({ open: false, type: '', data: {} as any });

  // Statistics
  const { data: allUsers } = useCollection(collection(db, "users"));
  const { data: allProducts } = useCollection(collection(db, "products"));
  const reportedQuery = query(collection(db, "products"), where("isReported", "==", true));
  const { data: reportedProducts } = useCollection(reportedQuery);

  useEffect(() => {
    const mockMode = localStorage.getItem('vicks_admin_mode');
    const accessGranted = localStorage.getItem('admin_access_granted');
    if (mockMode === 'active' && accessGranted) {
      setIsAdminLocal(true);
    }
  }, []);

  // محرك معالجة الأوامر الزمنية المختصرة (يدعم 3m, 6m, 10m إلخ)
  const parseDurationCommand = (command: string): string | null => {
    const cmd = command.toLowerCase().trim();
    if (cmd === 'permanent' || cmd === 'p' || cmd === 'inf') return null;

    const match = cmd.match(/^(\d+)([hdwmy])$/);
    if (!match) return null;

    const value = parseInt(match[1]);
    const unit = match[2];
    const date = new Date();

    switch (unit) {
      case 'h': date.setHours(date.getHours() + value); break;
      case 'd': date.setDate(date.getDate() + value); break;
      case 'w': date.setDate(date.getDate() + value * 7); break;
      case 'm': date.setMonth(date.getMonth() + value); break;
      case 'y': date.setFullYear(date.getFullYear() + value); break;
      default: return null;
    }

    return date.toISOString();
  };

  const findUserByUniqueId = async (id: string) => {
    const q = query(collection(db, "users"), where("unique_id", "==", id.trim()));
    const snap = await getDocs(q);
    if (snap.empty) return null;
    return { ...snap.docs[0].data(), uid: snap.docs[0].id };
  };

  const handlePointsAction = async (action: 'add' | 'sub') => {
    if (!targetId || !pointsAmount) return;
    setLoadingAction(true);
    try {
      const targetUser = await findUserByUniqueId(targetId);
      if (!targetUser) {
        toast({ variant: "destructive", title: "خطأ", description: "لم يتم العثور على الـ ID المطلوب." });
        return;
      }
      
      const amount = parseInt(pointsAmount);
      const finalAmount = action === 'add' ? amount : -amount;
      
      await updateDoc(doc(db, "users", targetUser.uid), {
        points: increment(finalAmount)
      });
      
      toast({ title: "تم تحديث الرصيد", description: `تم ${action === 'add' ? 'إضافة' : 'خصم'} ${amount} نقطة للحساب ${targetId}` });
      setPointsAmount("");
    } catch (e) {
      toast({ variant: "destructive", title: "فشل العملية" });
    } finally {
      setLoadingAction(false);
      setConfirmModal({ ...confirmModal, open: false });
    }
  };

  const handleGrantVerification = async () => {
    if (!targetId) return;
    setLoadingAction(true);
    try {
      const targetUser = await findUserByUniqueId(targetId);
      if (!targetUser) {
        toast({ variant: "destructive", title: "خطأ", description: "الـ ID غير موجود." });
        return;
      }

      const expiryDate = parseDurationCommand(verifDuration);

      await updateDoc(doc(db, "users", targetUser.uid), {
        isVerified: true,
        verificationType: verifType,
        verificationExpiresAt: expiryDate,
        role: "merchant"
      });

      toast({ 
        title: "تم منح التوثيق", 
        description: `الحساب ${targetId} حصل على الشارة ${verifType === 'gold' ? 'الذهبية' : 'الزرقاء'} لمدّة الطلب.` 
      });
    } catch (e) {
      toast({ variant: "destructive", title: "فشل منح التوثيق" });
    } finally {
      setLoadingAction(false);
    }
  };

  const handleShadowBan = async () => {
    if (!targetId) return;
    setLoadingAction(true);
    try {
      const targetUser = await findUserByUniqueId(targetId);
      if (!targetUser) {
        toast({ variant: "destructive", title: "خطأ", description: "الـ ID غير موجود." });
        return;
      }

      const expiryDate = parseDurationCommand(banTime);

      await updateDoc(doc(db, "users", targetUser.uid), {
        status: "suspended",
        banExpiresAt: expiryDate,
        warningMessage: "تم تقييد حسابك لمخالفة القوانين، تواصل مع الإدارة للتفاصيل."
      });

      toast({ 
        title: "تم تفعيل الحظر الظلي", 
        description: `الحساب ${targetId} مقيد حالياً بالمدة المحددة.` 
      });
    } catch (e) {
      toast({ variant: "destructive", title: "فشل العملية" });
    } finally {
      setLoadingAction(false);
    }
  };

  const switchRole = (role: string) => {
    localStorage.setItem('vicks_temp_role', role);
    toast({ title: `تم التحول إلى رتبة: ${role === 'merchant' ? 'تاجر' : 'زبون'}` });
    router.push('/');
  };

  const handleLogout = async () => {
    localStorage.removeItem('vicks_admin_mode');
    localStorage.removeItem('admin_access_granted');
    localStorage.removeItem('admin_email');
    localStorage.removeItem('vicks_temp_role');
    await signOut(auth);
    router.push('/login');
  };

  if (userLoading && !isAdminLocal) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="animate-spin text-orange-500 w-12 h-12" /></div>;
  
  const isAuthorized = isAdminLocal || (user && user.email && ADMIN_EMAILS.includes(user.email));

  if (!isAuthorized) {
    if (!userLoading) router.replace('/login');
    return null;
  }

  return (
    <div className="min-h-screen bg-[#F8F9FA] dark:bg-[#1A2332] text-right font-cairo pb-24" dir="rtl">
      {/* Role Switcher Bar */}
      <div className="bg-slate-900 text-white px-6 py-2 flex items-center justify-between border-b border-orange-500/30">
         <div className="flex items-center gap-4">
            <span className="text-[10px] font-black text-orange-500 uppercase tracking-widest">اختبار الأدوار:</span>
            <div className="flex gap-2">
               <Button onClick={() => switchRole('merchant')} size="sm" className="h-7 rounded-full bg-blue-600 hover:bg-blue-700 text-[9px] font-black gap-1">
                 <Store className="w-3 h-3" /> حساب تاجر
               </Button>
               <Button onClick={() => switchRole('customer')} size="sm" className="h-7 rounded-full bg-slate-700 hover:bg-slate-600 text-[9px] font-black gap-1">
                 <UserCircle className="w-3 h-3" /> حساب زبون
               </Button>
               <Button disabled className="h-7 rounded-full bg-orange-500 text-white text-[9px] font-black opacity-100">
                 <Crown className="w-3 h-3" /> لوحة المالك (نشط)
               </Button>
            </div>
         </div>
         <p className="text-[8px] font-bold text-slate-400">خاص بالـ ID: 1000000000 فقط</p>
      </div>

      <header className="flex items-center justify-between px-6 py-4 border-b bg-white dark:bg-[#1A2332] sticky top-0 z-50 shadow-sm">
        <button onClick={() => router.push('/')} className="w-12 h-12 flex items-center justify-center bg-slate-50 dark:bg-slate-800 rounded-2xl shadow-sm hover:scale-105 transition-transform">
          <Home className="w-6 h-6 text-slate-600 dark:text-slate-300" />
        </button>
        <div className="flex items-center gap-3">
          <div className="flex flex-col items-end leading-none">
            <span className="font-black text-lg text-slate-800 dark:text-white uppercase">مركز القيادة الأسطوري</span>
            <span className="text-[10px] text-orange-500 font-bold uppercase tracking-widest">ID: 1000000000 • السيادة المطلقة</span>
          </div>
          <VicksLogo className="w-10 h-10" />
        </div>
        <button onClick={handleLogout} className="w-12 h-12 flex items-center justify-center bg-red-50 text-red-500 rounded-2xl">
          <LogOut className="w-6 h-6" />
        </button>
      </header>

      <main className="px-6 space-y-8 max-w-7xl mx-auto pt-8">
        {/* Statistics Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
           <div className="bg-white dark:bg-slate-800 p-5 rounded-[2rem] border-b-4 border-blue-500 shadow-sm">
              <Users className="w-5 h-5 text-blue-500 mb-2" />
              <p className="text-[10px] font-bold text-slate-400 uppercase">المواطنين</p>
              <p className="text-2xl font-black dark:text-white">{allUsers?.length || 0}</p>
           </div>
           <div className="bg-white dark:bg-slate-800 p-5 rounded-[2rem] border-b-4 border-orange-500 shadow-sm">
              <ShoppingCart className="w-5 h-5 text-orange-500 mb-2" />
              <p className="text-[10px] font-bold text-slate-400 uppercase">السلع النشطة</p>
              <p className="text-2xl font-black dark:text-white">{allProducts?.length || 0}</p>
           </div>
           <div className="bg-white dark:bg-slate-800 p-5 rounded-[2rem] border-b-4 border-red-500 shadow-sm">
              <ShieldAlert className="w-5 h-5 text-red-500 mb-2" />
              <p className="text-[10px] font-bold text-slate-400 uppercase">البلاغات</p>
              <p className="text-2xl font-black dark:text-white">{reportedProducts?.length || 0}</p>
           </div>
           <div className="bg-white dark:bg-slate-800 p-5 rounded-[2rem] border-b-4 border-yellow-500 shadow-sm cursor-pointer hover:scale-105 transition-transform" onClick={() => router.push('/vip')}>
              <Crown className="w-5 h-5 text-yellow-500 mb-2" />
              <p className="text-[10px] font-bold text-slate-400 uppercase">مركز الـ VIP</p>
              <p className="text-sm font-black dark:text-white">دخول سريع</p>
           </div>
        </div>

        <Tabs defaultValue="economy" className="w-full">
           <TabsList className="bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl h-16 w-full flex justify-between gap-2 overflow-x-auto no-scrollbar">
              <TabsTrigger value="economy" className="flex-1 rounded-xl data-[state=active]:bg-white font-black text-[10px] gap-2">
                 <Wallet className="w-3.5 h-3.5" /> بنك النقاط
              </TabsTrigger>
              <TabsTrigger value="verification" className="flex-1 rounded-xl data-[state=active]:bg-white font-black text-[10px] gap-2">
                 <ShieldCheck className="w-3.5 h-3.5" /> التوثيقات
              </TabsTrigger>
              <TabsTrigger value="justice" className="flex-1 rounded-xl data-[state=active]:bg-white font-black text-[10px] gap-2">
                 <Gavel className="w-3.5 h-3.5" /> العدالة
              </TabsTrigger>
           </TabsList>

           {/* Section 1: Points Bank */}
           <TabsContent value="economy" className="mt-6">
              <div className="bg-white dark:bg-slate-800 p-8 rounded-[3rem] shadow-xl border-t-8 border-emerald-500">
                 <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 bg-emerald-100 rounded-2xl flex items-center justify-center text-emerald-600">
                       <Zap className="w-6 h-6 fill-current" />
                    </div>
                    <h2 className="text-xl font-black">بنك النقاط المركزي</h2>
                 </div>
                 
                 <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                       <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-400 uppercase pr-2">رقم الـ ID للمستهدف</label>
                          <div className="relative">
                             <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                             <Input value={targetId} onChange={(e) => setTargetId(e.target.value)} placeholder="مثلاً: 100025" className="h-14 rounded-2xl border-2 pr-12 font-black text-lg" />
                          </div>
                       </div>
                       <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-400 uppercase pr-2">عدد النقاط</label>
                          <div className="relative">
                             <Wallet className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-orange-500" />
                             <Input type="number" value={pointsAmount} onChange={(e) => setPointsAmount(e.target.value)} placeholder="0" className="h-14 rounded-2xl border-2 pr-12 font-black text-lg text-orange-600" />
                          </div>
                       </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                       <Button onClick={() => setConfirmModal({ open: true, type: 'points_add', data: { id: targetId, amount: pointsAmount } })} disabled={!targetId || !pointsAmount || loadingAction} className="h-16 bg-emerald-500 hover:bg-emerald-600 text-white rounded-2xl font-black text-lg shadow-lg">
                          إضافة نقاط +
                       </Button>
                       <Button onClick={() => setConfirmModal({ open: true, type: 'points_sub', data: { id: targetId, amount: pointsAmount } })} disabled={!targetId || !pointsAmount || loadingAction} variant="outline" className="h-16 border-2 border-red-100 text-red-500 hover:bg-red-50 rounded-2xl font-black text-lg shadow-sm">
                          خصم نقاط -
                       </Button>
                    </div>
                 </div>
              </div>
           </TabsContent>

           {/* Section 2: Verification Management */}
           <TabsContent value="verification" className="mt-6">
              <div className="bg-white dark:bg-slate-800 p-8 rounded-[3rem] shadow-xl border-t-8 border-blue-500">
                 <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600">
                       <ShieldCheck className="w-6 h-6" />
                    </div>
                    <h2 className="text-xl font-black">إدارة التوثيقات السيادية</h2>
                 </div>

                 <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                       <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-400 uppercase pr-2">رقم الـ ID</label>
                          <Input value={targetId} onChange={(e) => setTargetId(e.target.value)} placeholder="ID الحساب" className="h-14 rounded-2xl border-2 font-black" />
                       </div>
                       <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-400 uppercase pr-2">نوع التوثيق</label>
                          <Select value={verifType} onValueChange={setVerifType}>
                             <SelectTrigger className="h-14 rounded-2xl border-2 font-black">
                                <SelectValue />
                             </SelectTrigger>
                             <SelectContent className="font-cairo font-bold">
                                <SelectItem value="blue">توثيق أزرق قياسي 🔵</SelectItem>
                                <SelectItem value="gold">توثيق ذهبي ملكي 🟡</SelectItem>
                             </SelectContent>
                          </Select>
                       </div>
                       <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-400 uppercase pr-2">المدة (3m, 6m, 10m, p)</label>
                          <div className="relative">
                            <Clock className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                            <Input 
                              value={verifDuration} 
                              onChange={(e) => setVerifDuration(e.target.value)} 
                              placeholder="مثلاً: 3m أو 6m أو 10m" 
                              className="h-14 rounded-2xl border-2 pr-12 font-black text-center" 
                            />
                          </div>
                       </div>
                    </div>
                    <div className="bg-blue-50 dark:bg-blue-900/10 p-3 rounded-xl flex items-start gap-2 border border-blue-100">
                       <Info className="w-4 h-4 text-blue-500 mt-0.5" />
                       <p className="text-[10px] font-bold text-blue-600 leading-tight">
                         نظام الأوامر السريع: m = شهور (مثل 3m, 6m, 10m)، d = أيام، y = سنوات، p = دائم.
                       </p>
                    </div>
                    <Button onClick={handleGrantVerification} disabled={!targetId || loadingAction} className="w-full h-16 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black text-lg shadow-xl">
                       منح التوثيق بالأوامر المختصرة
                    </Button>
                 </div>
              </div>
           </TabsContent>

           {/* Section 3: Justice (Ban System) */}
           <TabsContent value="justice" className="mt-6">
              <div className="bg-white dark:bg-slate-800 p-8 rounded-[3rem] shadow-xl border-t-8 border-red-500">
                 <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 bg-red-100 rounded-2xl flex items-center justify-center text-red-600">
                       <Gavel className="w-6 h-6" />
                    </div>
                    <h2 className="text-xl font-black">نظام الحظر الظلي والمقيد</h2>
                 </div>

                 <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                       <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-400 uppercase pr-2">رقم الـ ID للمخالف</label>
                          <Input value={targetId} onChange={(e) => setTargetId(e.target.value)} placeholder="ID الحساب" className="h-14 rounded-2xl border-2 font-black" />
                       </div>
                       <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-400 uppercase pr-2">مدة الحظر (1h, 3d, 1m, 6m)</label>
                          <div className="relative">
                            <Clock className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-red-400" />
                            <Input 
                              value={banTime} 
                              onChange={(e) => setBanTime(e.target.value)} 
                              placeholder="مثلاً: 3m, 6m, 10m أو p" 
                              className="h-14 rounded-2xl border-2 pr-12 font-black text-center" 
                            />
                          </div>
                       </div>
                    </div>
                    <div className="bg-red-50 dark:bg-red-900/10 p-3 rounded-xl flex items-start gap-2 border border-red-100">
                       <Info className="w-4 h-4 text-red-500 mt-0.5" />
                       <p className="text-[10px] font-bold text-red-600 leading-tight">
                         يدعم النظام الآن الشهور الطويلة: 3m، 6m، 10m بضغطة زر.
                       </p>
                    </div>
                    <Button onClick={handleShadowBan} disabled={!targetId || loadingAction} className="w-full h-16 bg-red-600 hover:bg-red-700 text-white rounded-2xl font-black text-lg shadow-xl">
                       تفعيل الحظر بالأوامر المختصرة
                    </Button>
                 </div>
              </div>
           </TabsContent>
        </Tabs>
      </main>

      {/* Global Confirmation Modal */}
      <Dialog open={confirmModal.open} onOpenChange={(o) => setConfirmModal({ ...confirmModal, open: o })}>
         <DialogContent className="rounded-[2rem] font-cairo text-right" dir="rtl">
            <DialogHeader>
               <DialogTitle className="text-xl font-black flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-orange-500" /> تأكيد العملية السيادية
               </DialogTitle>
               <DialogDescription className="font-bold">
                  هل أنت متأكد من {confirmModal.type.includes('add') ? 'إضافة' : 'خصم'} 
                  <span className="text-orange-600 px-1">{confirmModal.data.amount}</span> نقطة 
                  للحساب صاحب الـ ID <span className="text-blue-600 px-1">{confirmModal.data.id}</span>؟
               </DialogDescription>
            </DialogHeader>
            <DialogFooter className="flex gap-2">
               <Button onClick={() => setConfirmModal({ ...confirmModal, open: false })} variant="outline" className="flex-1 rounded-xl font-black">إلغاء</Button>
               <Button 
                 onClick={() => handlePointsAction(confirmModal.type.includes('add') ? 'add' : 'sub')} 
                 className="flex-1 rounded-xl bg-slate-900 text-white font-black"
               >
                 تأكيد التنفيذ
               </Button>
            </DialogFooter>
         </DialogContent>
      </Dialog>
    </div>
  );
}
