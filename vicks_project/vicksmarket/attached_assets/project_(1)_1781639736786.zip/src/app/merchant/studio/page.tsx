
"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { 
  Store, ShoppingBag, Zap, Camera, Image as ImageIcon, 
  Plus, Loader2, Save, ArrowRight, Settings, Phone, MessageCircle, Globe, LayoutDashboard, Sparkles
} from "lucide-react";
import { useUser, useFirestore, useDoc } from "@/firebase";
import { doc, updateDoc, collection, addDoc, serverTimestamp } from "firebase/firestore";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { VicksLogo } from "@/components/VicksLogo";
import { cn } from "@/lib/utils";

export default function MerchantStudioPage() {
  const router = useRouter();
  const { user, loading: userLoading } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  
  const userProfileRef = user ? doc(db, "users", user.uid) : null;
  const { data: profile } = useDoc(userProfileRef);

  const [loading, setLoading] = useState(false);
  
  // Profile State
  const [shopData, setShopData] = useState({
    shopName: "",
    phone: "",
    telegram: "",
    photoURL: "",
    coverURL: ""
  });

  // Product State
  const [prodData, setProdData] = useState({
    name: "",
    price: "",
    description: "",
    category: "إلكترونيات",
    image: ""
  });

  // Story State
  const [storyImage, setStoryImage] = useState("");
  const [targetProductId, setTargetProductId] = useState("");

  useEffect(() => {
    if (profile) {
      setShopData({
        shopName: profile.shopName || profile.fullName || "",
        phone: profile.phone || "",
        telegram: profile.telegram || "",
        photoURL: profile.photoURL || "",
        coverURL: profile.coverURL || ""
      });
    }
  }, [profile]);

  const handleUpdateProfile = async () => {
    if (!userProfileRef) return;
    setLoading(true);
    try {
      await updateDoc(userProfileRef, {
        ...shopData,
        role: "merchant" // التأكد من تفعيل رتبة التاجر
      });
      toast({ title: "تم تحديث بيانات المتجر ✅" });
    } catch (e) {
      toast({ variant: "destructive", title: "فشل التحديث" });
    } finally {
      setLoading(false);
    }
  };

  const handleAddProduct = async () => {
    if (!user || !profile) return;
    setLoading(true);
    try {
      await addDoc(collection(db, "products"), {
        ...prodData,
        price: Number(prodData.price),
        seller: profile.shopName || profile.fullName,
        sellerId: user.uid,
        isOriginal: profile.isVerified,
        createdAt: new Date().toISOString(),
        views: 0,
        rating: 5
      });
      toast({ title: "تم نشر المنتج بنجاح 🛍️" });
      setProdData({ name: "", price: "", description: "", category: "إلكترونيات", image: "" });
    } catch (e) {
      toast({ variant: "destructive", title: "فشل النشر" });
    } finally {
      setLoading(false);
    }
  };

  const handlePostStory = async () => {
    if (!user || !profile) return;
    setLoading(true);
    try {
      await addDoc(collection(db, "stories"), {
        sellerId: user.uid,
        sellerName: profile.shopName || profile.fullName,
        sellerImage: profile.photoURL || "",
        image: storyImage || `https://picsum.photos/seed/${Date.now()}/1080/1920`,
        productId: targetProductId || null,
        isGold: profile.verificationType === 'gold',
        createdAt: new Date().toISOString(),
        expiresAt: Date.now() + (24 * 60 * 60 * 1000) // تختفي بعد 24 ساعة
      });
      toast({ title: "تم نشر الاستوري! 🔥" });
      setStoryImage("");
    } catch (e) {
      toast({ variant: "destructive", title: "فشل النشر" });
    } finally {
      setLoading(false);
    }
  };

  if (userLoading) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="animate-spin text-orange-500" /></div>;
  if (!user) { router.push('/login'); return null; }

  return (
    <div className="min-h-screen bg-[#F8F9FA] dark:bg-[#1A2332] font-cairo pb-20" dir="rtl">
      <header className="bg-white dark:bg-[#252D3D] p-6 shadow-sm flex items-center justify-between sticky top-0 z-50">
         <button onClick={() => router.push('/')} className="w-10 h-10 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center">
            <ArrowRight className="w-5 h-5" />
         </button>
         <div className="flex items-center gap-2">
            <div className="flex flex-col items-end">
               <span className="text-sm font-black dark:text-white uppercase tracking-tighter">Vicks Studio</span>
               <span className="text-[9px] text-orange-500 font-bold uppercase tracking-widest">إدارة المحتوى الملكي</span>
            </div>
            <VicksLogo className="w-8 h-8" />
         </div>
      </header>

      <main className="p-6 max-w-2xl mx-auto">
        <Tabs defaultValue="brand" className="w-full">
           <TabsList className="grid grid-cols-3 h-14 bg-slate-100 dark:bg-slate-800 rounded-2xl p-1 mb-8">
              <TabsTrigger value="brand" className="rounded-xl font-black text-[10px] gap-2 data-[state=active]:bg-white">
                <Store className="w-3.5 h-3.5" /> الهوية
              </TabsTrigger>
              <TabsTrigger value="product" className="rounded-xl font-black text-[10px] gap-2 data-[state=active]:bg-white">
                <ShoppingBag className="w-3.5 h-3.5" /> منتج
              </TabsTrigger>
              <TabsTrigger value="story" className="rounded-xl font-black text-[10px] gap-2 data-[state=active]:bg-white">
                <Zap className="w-3.5 h-3.5" /> استوري
              </TabsTrigger>
           </TabsList>

           {/* 1. إعدادات الهوية */}
           <TabsContent value="brand" className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
              <div className="bg-white dark:bg-[#252D3D] p-6 rounded-[2.5rem] shadow-sm border space-y-6">
                 <div className="space-y-3">
                    <Label className="text-xs font-black pr-2">رابط صورة الغلاف (140px height)</Label>
                    <div className="relative">
                       <ImageIcon className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                       <Input value={shopData.coverURL} onChange={(e) => setShopData({...shopData, coverURL: e.target.value})} placeholder="URL صورة الغلاف" className="h-12 rounded-xl pr-12 text-xs font-bold" />
                    </div>
                 </div>

                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-3">
                       <Label className="text-xs font-black pr-2">اسم المتجر</Label>
                       <Input value={shopData.shopName} onChange={(e) => setShopData({...shopData, shopName: e.target.value})} className="h-12 rounded-xl font-bold" />
                    </div>
                    <div className="space-y-3">
                       <Label className="text-xs font-black pr-2">رقم الواتساب (بدون +)</Label>
                       <div className="relative">
                          <Phone className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-500" />
                          <Input value={shopData.phone} onChange={(e) => setShopData({...shopData, phone: e.target.value})} placeholder="201xxxxxxxxx" className="h-12 rounded-xl pr-10 font-bold" />
                       </div>
                    </div>
                 </div>

                 <div className="space-y-3">
                    <Label className="text-xs font-black pr-2">معرف تليجرام (بدون @)</Label>
                    <div className="relative">
                       <MessageCircle className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-blue-500" />
                       <Input value={shopData.telegram} onChange={(e) => setShopData({...shopData, telegram: e.target.value})} placeholder="vicks_store" className="h-12 rounded-xl pr-10 font-bold" />
                    </div>
                 </div>

                 <Button onClick={handleUpdateProfile} disabled={loading} className="w-full h-14 bg-slate-900 text-white rounded-2xl font-black gap-2 shadow-lg">
                    {loading ? <Loader2 className="animate-spin" /> : <Save className="w-5 h-5" />}
                    حفظ إعدادات المتجر
                 </Button>
              </div>
           </TabsContent>

           {/* 2. إضافة منتج */}
           <TabsContent value="product" className="space-y-6">
              <div className="bg-white dark:bg-[#252D3D] p-6 rounded-[2.5rem] shadow-sm border space-y-4">
                 <div className="space-y-1.5">
                    <Label className="text-xs font-black pr-2">اسم المنتج</Label>
                    <Input value={prodData.name} onChange={(e) => setProdData({...prodData, name: e.target.value})} placeholder="ايفون 15 برو ماكس" className="h-12 rounded-xl" />
                 </div>
                 <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                       <Label className="text-xs font-black pr-2">السعر (ج.م)</Label>
                       <Input type="number" value={prodData.price} onChange={(e) => setProdData({...prodData, price: e.target.value})} placeholder="55000" className="h-12 rounded-xl" />
                    </div>
                    <div className="space-y-1.5">
                       <Label className="text-xs font-black pr-2">القسم</Label>
                       <Input value={prodData.category} onChange={(e) => setProdData({...prodData, category: e.target.value})} placeholder="إلكترونيات" className="h-12 rounded-xl" />
                    </div>
                 </div>
                 <div className="space-y-1.5">
                    <Label className="text-xs font-black pr-2">رابط صورة المنتج</Label>
                    <Input value={prodData.image} onChange={(e) => setProdData({...prodData, image: e.target.value})} placeholder="https://..." className="h-12 rounded-xl" />
                 </div>
                 <div className="space-y-1.5">
                    <Label className="text-xs font-black pr-2">وصف المنتج</Label>
                    <Textarea value={prodData.description} onChange={(e) => setProdData({...prodData, description: e.target.value})} className="rounded-xl min-h-[100px]" placeholder="اكتب تفاصيل المنتج بذكاء..." />
                 </div>
                 <Button onClick={handleAddProduct} disabled={loading} className="w-full h-14 bg-orange-500 hover:bg-orange-600 text-white rounded-2xl font-black gap-2 shadow-xl">
                    {loading ? <Loader2 className="animate-spin" /> : <Plus className="w-5 h-5" />}
                    نشر المنتج فوراً
                 </Button>
              </div>
           </TabsContent>

           {/* 3. نشر استوري */}
           <TabsContent value="story" className="space-y-6">
              <div className="bg-white dark:bg-[#252D3D] p-8 rounded-[3rem] shadow-sm border space-y-6">
                 <div className="text-center space-y-2">
                    <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto text-orange-500">
                       <Sparkles className="w-8 h-8" />
                    </div>
                    <h3 className="text-lg font-black">نشر استوري تسويقي</h3>
                    <p className="text-[10px] text-slate-400 font-bold">الاستوري تظهر في الصفحة الرئيسية وتختفي بعد 24 ساعة.</p>
                 </div>
                 
                 <div className="space-y-4">
                    <div className="space-y-1.5">
                       <Label className="text-xs font-black pr-2">رابط صورة الاستوري (طولية 1080x1920)</Label>
                       <Input value={storyImage} onChange={(e) => setStoryImage(e.target.value)} placeholder="https://..." className="h-12 rounded-xl" />
                    </div>
                    <div className="space-y-1.5">
                       <Label className="text-xs font-black pr-2">رقم المنتج المربوط (اختياري)</Label>
                       <Input value={targetProductId} onChange={(e) => setTargetProductId(e.target.value)} placeholder="Product ID" className="h-12 rounded-xl" />
                    </div>
                    <Button onClick={handlePostStory} disabled={loading} className="w-full h-14 bg-gradient-to-r from-orange-500 to-pink-500 text-white rounded-2xl font-black gap-2 shadow-2xl">
                       {loading ? <Loader2 className="animate-spin" /> : <Zap className="w-5 h-5" />}
                       نشر الاستوري الآن
                    </Button>
                 </div>
              </div>
           </TabsContent>
        </Tabs>
      </main>

      <footer className="fixed bottom-6 left-1/2 -translate-x-1/2 w-auto">
         <Button onClick={() => router.push('/')} className="h-12 px-8 bg-slate-900 text-white rounded-full font-black shadow-2xl flex items-center gap-2 border-2 border-orange-500/20">
            <LayoutDashboard className="w-4 h-4 text-orange-500" />
            <span>عرض المتجر الحقيقي</span>
         </Button>
      </footer>
    </div>
  );
}
