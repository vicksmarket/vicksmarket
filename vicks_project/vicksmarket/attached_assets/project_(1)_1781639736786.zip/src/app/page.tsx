"use client";

import React, { useState, useMemo, Suspense } from "react";
import { VicksHeader } from "@/components/VicksHeader";
import { VicksCategoryBar } from "@/components/VicksCategoryBar";
import { VicksProductGrid } from "@/components/VicksProductGrid";
import { VicksFooter } from "@/components/VicksFooter";
import { VicksStoriesBar } from "@/components/VicksStoriesBar";
import { Bot, Loader2 } from "lucide-react";
import { useRouter, useSearchParams } from "next/navigation";
import { useFirestore, useCollection, useUser, useDoc } from "@/firebase";
import { collection, query, orderBy, limit, where, doc } from "firebase/firestore";

/**
 * @fileOverview المحتوى الرئيسي بداخل Suspense لضمان استقرار السيرفر.
 */
function HomeContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const db = useFirestore();
  const { user } = useUser();
  const [activeCategory, setActiveCategory] = useState("الكل");

  const { data: profile } = useDoc(user ? doc(db, "users", user.uid) : null);
  const viewMode = (searchParams.get('view') as 'grid' | 'list') || 'grid';

  const trendingQuery = useMemo(() => query(
    collection(db, "products"),
    orderBy("views", "desc"),
    limit(10)
  ), [db]);

  const { data: trendingProducts } = useCollection(trendingQuery);

  return (
    <>
      <VicksCategoryBar onCategoryChange={setActiveCategory} activeCategory={activeCategory} />
      <VicksStoriesBar />

      <main className="flex-grow space-y-0" dir="rtl">
        {/* رف التريند */}
        <section>
          <h2 className="px-4 text-[10px] font-black text-orange-500 uppercase py-2">🔥 الأكثر رواجاً الآن</h2>
          <VicksProductGrid products={trendingProducts || undefined} layout={viewMode} category="الكل" />
        </section>

        {/* الرفوف المصنفة */}
        <VicksProductGrid category={activeCategory} layout={viewMode} />

        <div className="py-4 space-y-8">
          <section>
            <h2 className="px-4 text-xs font-black text-blue-500 uppercase mb-2">🏠 أدوات منزلية مختارة</h2>
            <VicksProductGrid category="أدوات منزلية" layout={viewMode} />
          </section>
          <section>
            <h2 className="px-4 text-xs font-black text-emerald-500 uppercase mb-2">🌿 جمال وعناية</h2>
            <VicksProductGrid category="جمال وعناية" layout={viewMode} />
          </section>
        </div>
      </main>

      {/* زر AI العائم */}
      <button 
        onClick={() => router.push('/ai-chat')}
        className="fixed bottom-6 right-6 w-14 h-14 bg-orange-500 rounded-full shadow-2xl flex items-center justify-center text-white z-50 hover:scale-110 transition-transform active:scale-95 group"
      >
        <Bot className="w-6 h-6 group-hover:animate-bounce" />
        <div className="absolute top-0 left-0 w-4 h-4 bg-white dark:bg-[#252D3D] rounded-full flex items-center justify-center border-2 border-orange-500">
          <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse" />
        </div>
      </button>
    </>
  );
}

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen bg-white dark:bg-[#1A2332] pb-0" dir="rtl">
      <VicksHeader />
      <Suspense fallback={<div className="flex justify-center py-20"><Loader2 className="animate-spin text-orange-500" /></div>}>
        <HomeContent />
      </Suspense>
      <VicksFooter />
    </div>
  );
}
