
"use client";
import React, { useState, useEffect, useMemo } from "react";
import { useParams, useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import Image from "next/image";
import { 
  ArrowRight, Share2, Heart, Phone, Star, User, BadgeCheck, Loader2, 
  Send, MapPin, Eye, ShieldCheck, Zap, Sparkles, Video, MessageCircle
} from "lucide-react";
import { useUser, useFirestore, useDoc } from "@/firebase";
import { doc, updateDoc, increment, arrayUnion, arrayRemove } from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";
import { VicksCompareDialog } from "@/components/VicksCompareDialog";
import { cn } from "@/lib/utils";

export default function ProductDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  
  const [isFavorite, setIsFavorite] = useState(false);
  const [userRating, setUserRating] = useState(0);

  const productRef = useMemo(() => doc(db, "products", params.id as string), [db, params.id]);
  const { data: product, loading: productLoading } = useDoc(productRef);
  const userRef = useMemo(() => user ? doc(db, "users", user.uid) : null, [user, db]);
  const { data: profile } = useDoc(userRef);

  const isBanned = profile?.status === 'banned' || profile?.status === 'suspended';
  const isVerified = user?.emailVerified;

  useEffect(() => {
    if (params.id) {
      updateDoc(doc(db, "products", params.id as string), { views: increment(1) });
    }
  }, [params.id, db]);

  useEffect(() => {
    if (profile && params.id) {
      setIsFavorite(profile.likedProducts?.includes(params.id));
    }
  }, [profile, params.id]);

  const toggleFavorite = async () => {
    if (!user || !userRef) { router.push("/login"); return; }
    
    if (!isVerified) {
      toast({ variant: "destructive", title: "بريد غير مفعل", description: "يجب تفعيل بريدك لتتمكن من إضافة المنتجات للمفضلة." });
      return;
    }

    if (isBanned) {
      toast({ variant: "destructive", title: "خطأ في الاتصال", description: "عذراً، حدث خطأ في الخادم، يرجى المحاولة لاحقاً." });
      return;
    }

    if (isFavorite) {
      await updateDoc(userRef, { likedProducts: arrayRemove(params.id) });
      toast({ title: "تمت الإزالة من المفضلة" });
    } else {
      await updateDoc(userRef, { likedProducts: arrayUnion(params.id) });
      toast({ title: "تمت الإضافة للمفضلة" });
    }
  };

  const handleRate = async (stars: number) => {
    if (!user) { router.push("/login"); return; }
    if (!isVerified) {
      toast({ variant: "destructive", title: "بريد غير مفعل", description: "فعل بريدك لتقييم المنتجات." });
      return;
    }
    
    setUserRating(stars);
    toast({ title: "شكراً لتقييمك!", description: `لقد منحت هذا المنتج ${stars} نجوم.` });
    // هنا سيتم إضافة الـ logic الفعلي لتحديث متوسط التقييم في الفايربيز لاحقاً
  };

  const handleGuaranteedBuy = () => {
    if (!user) { router.push('/login'); return; }
    if (!isVerified) {
      toast({ variant: "destructive", title: "بريد غير مفعل", description: "برجاء تفعيل بريدك لإتمام عمليات الشراء بضمان." });
      return;
    }
    if (isBanned) {
      toast({ variant: "destructive", title: "خطأ في السيرفر", description: "عذراً، حدث خطأ في الخادم، يرجى المحاولة لاحقاً." });
      return;
    }
    toast({ 
      title: "نظام ضمان فيكس النشط", 
      description: "سيتم تعليق النقاط في حساب وسيط حتى تأكيد الاستلام من طرفك لضمان حقك كاملاً." 
    });
  };

  const handleContact = () => {
    if (!user) { router.push('/login'); return; }
    if (!isVerified) {
      toast({ variant: "destructive", title: "بريد غير مفعل", description: "يجب تفعيل بريدك للتواصل مع التاجر." });
      return;
    }
    if (isBanned) {
      toast({ variant: "destructive", title: "خطأ تقني", description: "عذراً، حدث خطأ في الخادم، يرجى المحاولة لاحقاً." });
      return;
    }
    window.open(`https://wa.me/${product?.phone || '201113694362'}`, '_blank');
  };

  if (productLoading) return <div className="min-h-screen flex items-center justify-center bg-white dark:bg-[#1A2332]"><Loader2 className="animate-spin text-orange-500 w-12 h-12" /></div>;
  if (!product) return <div className="min-h-screen flex items-center justify-center font-black">المنتج غير موجود في قاعدة بيانات فيكس</div>;

  return (
    <div className="min-h-screen bg-[#F8F9FA] dark:bg-[#1A2332] p-4 md:p-8 font-cairo transition-colors" dir="rtl">
      <div className="max-w-4xl mx-auto bg-white dark:bg-[#252D3D] rounded-[3.5rem] shadow-2xl overflow-hidden pb-16 border dark:border-slate-800">
        <header className="p-6 flex items-center justify-between sticky top-0 bg-white/80 dark:bg-[#252D3D]/80 backdrop-blur-md z-10 border-b dark:border-slate-800">
          <button onClick={() => router.back()} className="w-10 h-10 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center shadow-sm">
            <ArrowRight className="w-5 h-5 dark:text-white" />
          </button>
          <div className="flex gap-2">
            <VicksCompareDialog productName={product.name} price={product.price} category={product.category}>
              <button className="h-10 px-5 bg-orange-50 dark:bg-orange-950/20 text-orange-600 rounded-full flex items-center gap-2 font-black text-[10px] border-2 border-orange-100 hover:scale-105 transition-transform">
                <Sparkles className="w-3.5 h-3.5" /> قارن بذكاء فيكس
              </button>
            </VicksCompareDialog>
            <button className="w-10 h-10 rounded-full bg-slate-50 dark:bg-slate-800 flex items-center justify-center shadow-sm">
              <Share2 className="w-5 h-5 dark:text-white" />
            </button>
          </div>
        </header>

        <div className="relative aspect-[16/10] md:aspect-[21/9] px-6 group">
          {product.videoUrl ? (
             <div className="w-full h-full rounded-[3rem] overflow-hidden bg-black relative shadow-inner">
                <video src={product.videoUrl} className="w-full h-full object-cover" controls autoPlay muted loop />
                <div className="absolute top-6 left-6 bg-red-600 text-white text-[9px] font-black px-4 py-1.5 rounded-full flex items-center gap-2 shadow-lg border-2 border-white/20">
                   <Video className="w-3.5 h-3.5 animate-pulse" /> REELS ACTIVE
                </div>
             </div>
          ) : (
             <div className="w-full h-full relative">
               <Image src={product.image} alt={product.name} fill className="object-contain p-6 drop-shadow-2xl" />
               <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.02] select-none">
                  <span className="text-7xl font-black text-slate-900 rotate-[-45deg] whitespace-nowrap uppercase">VICKS MARKET</span>
               </div>
             </div>
          )}
        </div>

        <div className="px-8 md:px-12 space-y-8 mt-6">
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2 flex-wrap">
                 <h1 className="text-3xl font-black dark:text-white leading-tight">{product.name}</h1>
                 {product.isOriginal && (
                   <div className="bg-yellow-500 p-1 rounded-full shadow-lg">
                      <BadgeCheck className="w-5 h-5 text-white" />
                   </div>
                 )}
              </div>
              
              {/* نظام التقييم التفاعلي */}
              <div className="flex items-center gap-2">
                 <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <button key={s} onClick={() => handleRate(s)} className="transition-transform active:scale-125">
                         <Star className={cn("w-6 h-6", (userRating || product.rating || 5) >= s ? "text-yellow-400 fill-current" : "text-slate-200")} />
                      </button>
                    ))}
                 </div>
                 <span className="text-xs font-black text-slate-400">({product.rating || 5}.0)</span>
              </div>

              <div className="flex items-center gap-3 pt-2">
                 <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest bg-slate-50 dark:bg-slate-800 px-3 py-1 rounded-full">{product.category}</p>
                 <div className="flex items-center gap-1.5 bg-blue-50 dark:bg-blue-900/10 px-3 py-1 rounded-full border border-blue-100">
                   <MapPin className="w-3.5 h-3.5 text-blue-500" />
                   <span className="text-[10px] font-black text-blue-600">{product.location || "القاهرة"}</span>
                 </div>
              </div>
            </div>
            <div className="text-right">
               <p className="text-orange-500 text-4xl font-black tracking-tighter">{product.price.toLocaleString()} <span className="text-lg">ج.م</span></p>
               <div className="flex items-center justify-end gap-1.5 text-slate-300 mt-1">
                  <Eye className="w-3.5 h-3.5" />
                  <span className="text-[10px] font-bold">{product.views} مشاهدة ملكية</span>
               </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 max-w-sm mx-auto">
             <button onClick={toggleFavorite} className="flex flex-col items-center gap-2 group">
                <div className={cn(
                  "w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg transition-all duration-300 group-hover:scale-110", 
                  isFavorite 
                  ? "bg-orange-500 text-white shadow-orange-500/20 opacity-100" 
                  : "bg-white dark:bg-slate-800 text-red-500 border dark:border-slate-700 opacity-40 hover:opacity-100 hover:border-orange-500 active:bg-orange-500 active:text-white"
                )}>
                  <Heart className={cn("w-6 h-6", isFavorite && "fill-current")} />
                </div>
                <span className="text-[9px] font-black dark:text-slate-300 uppercase">المفضلة</span>
             </button>
             
             <button onClick={handleGuaranteedBuy} className="flex flex-col items-center gap-2 group">
                <div className="w-14 h-14 rounded-2xl bg-white dark:bg-slate-800 text-blue-600 flex items-center justify-center shadow-lg border dark:border-slate-700 opacity-40 hover:opacity-100 hover:border-orange-500 active:bg-orange-500 active:text-white transition-all duration-300">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <span className="text-[9px] font-black dark:text-slate-300 uppercase">شراء بضمان</span>
             </button>

             <button onClick={handleContact} className="flex flex-col items-center gap-2 group">
                <div className="w-14 h-14 rounded-2xl bg-white dark:bg-slate-800 text-emerald-500 flex items-center justify-center shadow-lg border dark:border-slate-700 opacity-40 hover:opacity-100 hover:border-orange-500 active:bg-orange-500 active:text-white transition-all duration-300">
                  <MessageCircle className="w-6 h-6" />
                </div>
                <span className="text-[9px] font-black dark:text-slate-300 uppercase">واتساب</span>
             </button>
          </div>

          <div className="p-6 bg-slate-50 dark:bg-slate-800/50 rounded-[2.5rem] border dark:border-slate-800 space-y-3 shadow-inner">
             <h3 className="font-black text-md dark:text-white flex items-center gap-2">
                <div className="w-1.5 h-4 bg-orange-500 rounded-full" /> وصف المنتج
             </h3>
             <p className="text-xs text-slate-600 dark:text-slate-300 leading-loose font-medium">{product.description || "لا يوجد وصف متوفر لهذا المنتج الفاخر."}</p>
          </div>

          <div className="bg-slate-900 dark:bg-black p-6 rounded-[3rem] flex items-center justify-between shadow-2xl border-b-4 border-orange-500 transform hover:scale-[1.01] transition-transform">
             <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-slate-800 flex items-center justify-center text-slate-400 border-2 border-slate-700">
                  <User className="w-8 h-8" />
                </div>
                <div className="space-y-0.5">
                   <p className="text-xl font-black text-white">{product.seller}</p>
                   <div className="flex items-center gap-1.5">
                      <span className="text-[9px] text-orange-500 font-black uppercase tracking-widest">تاجر موثق بضمان فيكس</span>
                      <BadgeCheck className="w-3.5 h-3.5 text-blue-500 fill-white" />
                   </div>
                </div>
             </div>
             <Button 
               variant="outline" 
               className="h-12 px-6 rounded-xl text-[10px] font-black border-slate-700 text-white bg-slate-800/50 hover:bg-orange-500 hover:border-orange-500 transition-all" 
               onClick={() => {
                 if (!user) router.push('/login');
                 else if (!isVerified) toast({variant: "destructive", title: "بريد غير مفعل"});
                 else if (isBanned) toast({title: "خطأ", description: "عذراً، حدث خطأ في الخادم."});
                 else router.push(`/chat?id=${product.sellerId}`);
               }}
             >
                دردشة فورية
             </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
