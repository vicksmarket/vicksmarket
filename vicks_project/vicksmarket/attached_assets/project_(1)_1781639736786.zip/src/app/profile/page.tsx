
"use client";

import React, { useState, useMemo, useEffect } from "react";
import { useRouter } from "next/navigation";
import { 
  User, LogOut, Heart, Coins, BadgeCheck, Home, 
  Loader2, Mail, Phone, Lock, Eye, EyeOff, 
  Sparkles, ChevronRight, Globe, Key, UserPlus, ShoppingBag, Trash2, Store
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { useUser, useFirestore, useAuth, useDoc } from "@/firebase";
import { signOut } from "firebase/auth";
import { doc, updateDoc } from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";
import { VicksLogo } from "@/components/VicksLogo";

export default function ProfilePage() {
  const router = useRouter();
  const auth = useAuth();
  const { user, loading: userLoading } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  
  const [loading, setLoading] = useState(false);
  const [fullName, setFullName] = useState("");
  const [shopName, setShopName] = useState("");

  const userProfileRef = useMemo(() => user ? doc(db, "users", user.uid) : null, [user, db]);
  const { data: profile } = useDoc(userProfileRef);

  const isBanned = profile?.status === 'banned' || profile?.status === 'suspended';

  useEffect(() => {
    if (profile) {
      setFullName(profile.fullName || "");
      setShopName(profile.shopName || "");
    }
  }, [profile]);

  const handleUpdateName = async (type: 'fullName' | 'shopName') => {
    if (!userProfileRef || !profile) return;
    if (isBanned) {
      toast({ variant: "destructive", title: "خطأ في التزامن", description: "لم نتمكن من حفظ التغييرات، جرب لاحقاً." });
      return;
    }
    
    setLoading(true);
    const updateData = {
      [type]: type === 'fullName' ? fullName : shopName,
      [type === 'fullName' ? 'lastFullNameChange' : 'lastShopNameChange']: new Date().toISOString()
    };

    updateDoc(userProfileRef, updateData)
      .then(() => toast({ title: "تم التحديث بنجاح" }))
      .catch(() => toast({ variant: "destructive", title: "خطأ", description: "فشل التحديث." }))
      .finally(() => setLoading(false));
  };

  if (userLoading) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="animate-spin text-orange-500" /></div>;

  if (user && profile) {
    return (
      <div className="min-h-screen bg-[#F8F9FA] dark:bg-[#1A2332] text-right font-cairo p-6 pb-24" dir="rtl">
        <header className="flex items-center justify-between mb-8 max-w-md mx-auto">
           <button onClick={() => router.push('/')} className="w-10 h-10 flex items-center justify-center bg-white dark:bg-slate-800 rounded-full shadow-sm">
             <Home className="w-5 h-5 text-orange-500" />
           </button>
           <h1 className="font-black dark:text-white">إعدادات الحساب</h1>
           <VicksLogo className="w-8 h-8" />
        </header>

        <main className="max-w-md mx-auto space-y-6">
          <div className="bg-white dark:bg-slate-800 p-6 rounded-[2.5rem] shadow-sm space-y-6 border">
             {isBanned && (
               <div className="p-3 bg-red-100 dark:bg-red-900/20 text-red-600 rounded-xl text-[10px] font-black text-center">
                 تم تقييد حسابك مؤقتاً، بعض الميزات قد لا تعمل بشكل صحيح.
               </div>
             )}
             <div className="space-y-4">
                <div className="space-y-1.5">
                   <Label className="text-xs font-bold pr-2">الاسم بالكامل</Label>
                   <div className="flex gap-2">
                      <Input value={fullName} onChange={(e) => setFullName(e.target.value)} className="h-12 rounded-xl dark:bg-slate-900" />
                      <Button size="sm" onClick={() => handleUpdateName('fullName')} className="bg-orange-500 h-12 rounded-xl">حفظ</Button>
                   </div>
                </div>
                {profile.role === 'merchant' && (
                  <div className="space-y-1.5">
                    <Label className="text-xs font-bold pr-2">اسم المتجر</Label>
                    <div className="flex gap-2">
                        <Input value={shopName} onChange={(e) => setShopName(e.target.value)} className="h-12 rounded-xl dark:bg-slate-900" />
                        <Button size="sm" onClick={() => handleUpdateName('shopName')} className="bg-slate-900 h-12 rounded-xl">حفظ</Button>
                    </div>
                  </div>
                )}
             </div>
          </div>

          <Button onClick={() => signOut(auth).then(() => router.push('/login'))} variant="outline" className="w-full h-14 rounded-[2rem] border-2 border-red-100 text-red-500 font-black gap-2">
             <LogOut className="w-5 h-5" /> تسجيل الخروج
          </Button>
        </main>
      </div>
    );
  }

  return null;
}
