
"use client";

import React, { useState, useEffect, useMemo } from "react";
import { useRouter } from "next/navigation";
import { 
  User, Mail, Phone, Lock, MapPin, Loader2, 
  ChevronRight, UserPlus, Eye, EyeOff, Sparkles, ShieldCheck, Store, UserCircle, Send, RotateCw, Timer, MessageCircle, MessageSquare, Globe, AlertTriangle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { VicksLogo } from "@/components/VicksLogo";
import { useAuth, useFirestore, useDoc } from "@/firebase";
import { 
  createUserWithEmailAndPassword, 
  GoogleAuthProvider, 
  signInWithPopup, 
  FacebookAuthProvider,
  sendEmailVerification
} from "firebase/auth";
import { doc, setDoc, getDoc, serverTimestamp } from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";
import { sendOTPEmail, sendWhatsAppOTP } from "@/app/actions/auth-actions";
import { cn } from "@/lib/utils";

const worldCountries = [
  "أفغانستان", "ألبانيا", "الجزائر", "أندورا", "أنغولا", "الأرجنتين", "أرمينيا", "أستراليا", "النمسا", "أذربيجان", "البحرين", "بنغلاديش", "بلجيكا", "البرازيل", "بلغاريا", "كندا", "تشاد", "تشيلي", "الصين", "كولومبيا", "جزر القمر", "كرواتيا", "كوبا", "قبرص", "الدنمارك", "جيبوتي", "مصر", "فنلندا", "فرنسا", "ألمانيا", "اليونان", "المجر", "أيسلندا", "الهند", "إندونيسيا", "إيران", "العراق", "أيرلندا", "إيطاليا", "اليابان", "الأردن", "كازاخستان", "كينيا", "الكويت", "لبنان", "ليبيا", "لوكسمبورغ", "ماليزيا", "المالديف", "مالي", "المكسيك", "موناكو", "المغرب", "هولندا", "نيوزيلندا", "نيجيريا", "النرويج", "عُمان", "باكستان", "فلسطين", "بنما", "باراغواي", "بيرو", "الفلبين", "بولندا", "البرتغال", "قطر", "رومانيا", "روسيا", "السعودية", "السنغال", "صربيا", "سنغافورة", "سلوفاكيا", "سلوفينيا", "الصومال", "جنوب أفريقيا", "كوريا الجنوبية", "إسبانيا", "السودان", "السويد", "سويسرا", "سوريا", "تايوان", "تايلاند", "تونس", "تركيا", "أوكرانيا", "الإمارات", "المملكة المتحدة", "الولايات المتحدة", "أوروغواي", "أوزبكستان", "فيتنام", "اليمن"
];

const DISPOSABLE_DOMAINS = [
  'mailinator.com', 'mohmal.com', 'temp-mail.org', '10minutemail.com', 
  'guerrillamail.com', 'yopmail.com', 'sharklasers.com', 'dispostable.com',
  'getnada.com', 'maildrop.cc', 'mohmal.net', 'temp-mail.io'
];

const ADMIN_EMAILS = ["mom1113694362@gmail.com", "vicksmarket@gmail.com"];

export default function RegisterPage() {
  const router = useRouter();
  const auth = useAuth();
  const db = useFirestore();
  const { toast } = useToast();

  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [role, setRole] = useState<'customer' | 'merchant'>('customer');
  
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    location: "مصر",
    password: "",
    confirmPassword: ""
  });

  const [emailOtp, setEmailOtp] = useState("");
  const [sentEmailCode, setSentEmailCode] = useState<string | null>(null);
  const [emailTimer, setEmailTimer] = useState(0);

  const [whatsappOtp, setWhatsappOtp] = useState("");
  const [sentWhatsappCode, setSentWhatsappCode] = useState<string | null>(null);
  const [whatsappTimer, setWhatsappTimer] = useState(0);
  
  const [isTelegramVerified, setIsTelegramVerified] = useState(false);

  const telegramRef = useMemo(() => 
    (role === 'merchant' && formData.phone) ? doc(db, "temp_verifications", formData.phone.replace(/\D/g, '')) : null
  , [role, formData.phone, db]);

  const { data: telegramVerif } = useDoc(telegramRef);

  useEffect(() => {
    if (telegramVerif?.verified) {
      setIsTelegramVerified(true);
      toast({ title: "تم التوثيق عبر تليجرام!", description: "تأكدنا من رقمك يا ملك، يمكنك الإكمال الآن." });
    }
  }, [telegramVerif, toast]);

  useEffect(() => {
    let eTimer: NodeJS.Timeout;
    if (emailTimer > 0) eTimer = setInterval(() => setEmailTimer(t => t - 1), 1000);
    return () => clearInterval(eTimer);
  }, [emailTimer]);

  useEffect(() => {
    let wTimer: NodeJS.Timeout;
    if (whatsappTimer > 0) wTimer = setInterval(() => setWhatsappTimer(t => t - 1), 1000);
    return () => clearInterval(wTimer);
  }, [whatsappTimer]);

  const handleSendEmailOtp = async () => {
    if (!formData.email) return;
    
    const domain = formData.email.split('@')[1];
    if (DISPOSABLE_DOMAINS.includes(domain)) {
      toast({ variant: "destructive", title: "بريد وهمي!", description: "عذراً يا ملك، ممنوع استخدام إيميلات مؤقتة. استخدم جيميل أو ياهو." });
      return;
    }

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setSentEmailCode(code);
    setEmailTimer(60);
    await sendOTPEmail(formData.email, code, 'verification');
    toast({ title: "تم إرسال كود التحقق للإيميل!" });
  };

  const handleSendWhatsappOtp = async () => {
    if (!formData.phone) return;
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setSentWhatsappCode(code);
    setWhatsappTimer(60);
    await sendWhatsAppOTP(formData.phone, code);
    toast({ title: "كود الواتساب في الطريق إليك الآن." });
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const domain = formData.email.split('@')[1];
    if (DISPOSABLE_DOMAINS.includes(domain)) {
      toast({ variant: "destructive", title: "بريد مرفوض", description: "استخدم بريد حقيقي لنتمكن من إرسال رابط التفعيل." });
      return;
    }

    if (emailOtp !== sentEmailCode) {
      toast({ variant: "destructive", title: "كود الإيميل غير صحيح" });
      return;
    }
    if (role === 'merchant' && !isTelegramVerified && whatsappOtp !== sentWhatsappCode) {
      toast({ variant: "destructive", title: "توثيق الهاتف مطلوب للتاجر" });
      return;
    }
    if (formData.password !== formData.confirmPassword) {
      toast({ variant: "destructive", title: "كلمات المرور غير متطابقة" });
      return;
    }

    setLoading(true);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, formData.email.trim().toLowerCase(), formData.password);
      const user = userCredential.user;

      await sendEmailVerification(user);
      
      const isAdmin = ADMIN_EMAILS.includes(formData.email.toLowerCase());
      const uniqueId = isAdmin ? "1000000000" : Math.floor(10000000 + Math.random() * 90000000).toString();

      await setDoc(doc(db, "users", user.uid), {
        fullName: formData.fullName,
        shopName: role === 'merchant' ? formData.fullName : null,
        email: formData.email.toLowerCase(),
        phone: formData.phone,
        location: formData.location,
        role: isAdmin ? "owner" : role,
        status: "active",
        points: isAdmin ? 1000000 : 50,
        unique_id: uniqueId,
        isVerified: isAdmin || role === 'customer',
        createdAt: serverTimestamp()
      });

      toast({ 
        title: "تم إنشاء الحساب بنجاح! 📩", 
        description: "يرجى فتح بريدك الآن والضغط على رابط التفعيل لتتمكن من الدخول للموقع." 
      });
      router.push('/login');
    } catch (error: any) {
      toast({ variant: "destructive", title: "فشل التسجيل", description: error.message });
    } finally {
      setLoading(false);
    }
  };

  const handleSocialRegister = async (providerName: 'google' | 'facebook') => {
    setLoading(true);
    try {
      const provider = providerName === 'google' ? new GoogleAuthProvider() : new FacebookAuthProvider();
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      
      const userRef = doc(db, "users", user.uid);
      const userSnap = await getDoc(userRef);

      const isAdmin = user.email && ADMIN_EMAILS.includes(user.email.toLowerCase());

      if (!userSnap.exists()) {
        const uniqueId = isAdmin ? "1000000000" : Math.floor(10000000 + Math.random() * 90000000).toString();
        
        const initialData = {
          fullName: user.displayName || "مستخدم فيكس",
          email: user.email,
          role: isAdmin ? "owner" : role,
          points: isAdmin ? 1000000 : 50,
          status: 'active',
          unique_id: uniqueId,
          isVerified: user.emailVerified || isAdmin, 
          photoURL: user.photoURL,
          createdAt: serverTimestamp()
        };

        await setDoc(userRef, initialData);
      }
      
      router.push('/');
    } catch (error: any) {
      toast({ variant: "destructive", title: "خطأ", description: "فشل التسجيل الاجتماعي." });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-[#1A2332] text-right font-cairo pb-10" dir="rtl">
      <header className="flex items-center justify-between px-6 py-6 border-b dark:border-slate-800 sticky top-0 bg-white dark:bg-[#1A2332] z-50">
        <button onClick={() => router.push('/login')} className="w-10 h-10 flex items-center justify-center bg-slate-50 dark:bg-slate-800 rounded-full">
          <ChevronRight className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-2">
          <span className="font-black text-lg uppercase tracking-tighter text-[#1A2332] dark:text-white">V Fix Market</span>
          <VicksLogo className="w-8 h-8" />
        </div>
      </header>

      <main className="px-6 mt-8 space-y-8 max-w-md mx-auto">
        <div className="bg-orange-50 dark:bg-orange-950/20 p-4 rounded-2xl border-2 border-dashed border-orange-200 flex items-center gap-3">
           <AlertTriangle className="w-6 h-6 text-orange-500" />
           <p className="text-[10px] font-black text-orange-600">ملاحظة: التسجيل بالإيميلات المؤقتة محظور تماماً لضمان أمان الموقع.</p>
        </div>

        <div className="text-center space-y-2">
          <h2 className="text-3xl font-black dark:text-white">إنشاء حساب جديد</h2>
          <p className="text-slate-400 text-sm font-bold uppercase tracking-widest">اختر رتبتك وانضم لعالم فيكس</p>
        </div>

        <div className="grid grid-cols-2 gap-4 p-2 bg-slate-100 dark:bg-slate-800 rounded-3xl">
          <button type="button" onClick={() => setRole('customer')} className={cn("flex flex-col items-center gap-2 py-4 rounded-2xl transition-all", role === 'customer' ? "bg-white dark:bg-slate-700 shadow-lg text-orange-500 scale-105" : "text-slate-400")}>
            <UserCircle className="w-8 h-8" />
            <span className="font-black text-[10px] uppercase">حساب زبون (سريع)</span>
          </button>
          <button type="button" onClick={() => setRole('merchant')} className={cn("flex flex-col items-center gap-2 py-4 rounded-2xl transition-all", role === 'merchant' ? "bg-white dark:bg-slate-700 shadow-lg text-blue-500 scale-105" : "text-slate-400")}>
            <Store className="w-8 h-8" />
            <span className="font-black text-[10px] uppercase">حساب تاجر (موثق)</span>
          </button>
        </div>

        <form onSubmit={handleRegister} className="space-y-5">
          <div className="space-y-4 bg-slate-50 dark:bg-slate-900/50 p-6 rounded-[2.5rem] border-2 border-slate-100 dark:border-slate-800 shadow-inner">
            
            <div className="relative">
              <User className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-orange-500" />
              <Input required value={formData.fullName} onChange={(e) => setFormData({...formData, fullName: e.target.value})} placeholder={role === 'merchant' ? "اسم المتجر التجاري" : "الاسم بالكامل"} className="h-14 rounded-2xl border-2 border-white pr-12 font-bold dark:bg-slate-800" />
            </div>

            <div className="space-y-3">
              <div className="relative flex gap-2">
                <div className="relative flex-1">
                  <Mail className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-orange-500" />
                  <Input required type="email" value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} placeholder="البريد الإلكتروني الحقيقي" className="h-14 rounded-2xl border-2 border-white pr-12 font-bold dark:bg-slate-800" />
                </div>
                <Button type="button" onClick={handleSendEmailOtp} disabled={!formData.email || emailTimer > 0} className="h-14 rounded-2xl px-4 bg-slate-900 text-white font-black text-[10px]">
                   {emailTimer > 0 ? `${emailTimer}ث` : "إرسال كود"}
                </Button>
              </div>
              
              {sentEmailCode && (
                <div className="flex items-center gap-2 animate-in slide-in-from-top-2 bg-white dark:bg-slate-900 p-2 rounded-2xl border-2 border-orange-100">
                  <div className="flex-1">
                     <Input required maxLength={6} value={emailOtp} onChange={(e) => setEmailOtp(e.target.value.replace(/\D/g, ""))} placeholder="000000" className="h-12 rounded-xl text-center font-black tracking-[0.5rem] border-none shadow-none text-xl" />
                  </div>
                  <Button type="button" onClick={handleSendEmailOtp} disabled={emailTimer > 0} className="text-[10px] font-black text-orange-500 min-w-[100px] border-r pr-2">
                    {emailTimer > 0 ? `أرسل ثانية (${emailTimer})` : "إعادة إرسال"}
                  </Button>
                </div>
              )}
            </div>

            {role === 'merchant' && (
              <div className="space-y-3">
                <div className="relative flex gap-2">
                   <div className="relative flex-1">
                    <Phone className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-500" />
                    <Input required type="tel" value={formData.phone} onChange={(e) => setFormData({...formData, phone: e.target.value})} placeholder="رقم الهاتف (201...)" className="h-14 rounded-2xl border-2 border-white pr-12 font-bold dark:bg-slate-800" />
                  </div>
                  <Button type="button" onClick={handleSendWhatsappOtp} disabled={!formData.phone || whatsappTimer > 0} className="h-14 rounded-2xl px-4 bg-emerald-500 text-white font-black text-[10px]">
                     واتساب
                  </Button>
                </div>

                {sentWhatsappCode && (
                  <div className="flex items-center gap-2 animate-in slide-in-from-top-2 bg-white dark:bg-slate-900 p-2 rounded-2xl border-2 border-emerald-100">
                    <div className="flex-1">
                       <Input required maxLength={6} value={whatsappOtp} onChange={(e) => setWhatsappOtp(e.target.value.replace(/\D/g, ""))} placeholder="000000" className="h-12 rounded-xl text-center font-black tracking-[0.5rem] border-none shadow-none text-xl text-emerald-600" />
                    </div>
                    <Button type="button" onClick={handleSendWhatsappOtp} disabled={whatsappTimer > 0} className="text-[10px] font-black text-emerald-500 min-w-[100px] border-r pr-2">
                      {whatsappTimer > 0 ? `أرسل ثانية (${whatsappTimer})` : "إعادة إرسال"}
                    </Button>
                  </div>
                )}

                <Button type="button" onClick={() => window.open("https://t.me/VFixMarketBot", "_blank")} variant="outline" className={cn("w-full h-12 rounded-xl border-2 font-black text-[10px] gap-2", isTelegramVerified ? "bg-blue-50 text-blue-600 border-blue-100" : "text-blue-500 border-blue-100")}>
                   <MessageSquare className="w-4 h-4" /> 
                   {isTelegramVerified ? "تم التوثيق عبر تليجرام ✅" : "أو التوثيق المجاني عبر تليجرام"}
                </Button>
              </div>
            )}

            <div className="relative">
              <Globe className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-orange-500 z-10" />
              <Select value={formData.location} onValueChange={(val) => setFormData({...formData, location: val})}>
                <SelectTrigger className="h-14 rounded-2xl border-2 border-white pr-12 font-bold dark:bg-slate-800">
                  <SelectValue placeholder="اختر دولتك" />
                </SelectTrigger>
                <SelectContent className="rounded-2xl font-cairo max-h-60">
                   {worldCountries.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="relative">
              <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-orange-500" />
              <Input required type={showPassword ? "text" : "password"} value={formData.password} onChange={(e) => setFormData({...formData, password: e.target.value})} placeholder="كلمة المرور" className="h-14 rounded-2xl border-2 border-white pr-12 pl-12 font-bold text-center dark:bg-slate-800" />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300">
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
            <Input required type={showPassword ? "text" : "password"} value={formData.confirmPassword} onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})} placeholder="تأكيد كلمة المرور" className="h-14 rounded-2xl border-2 border-white text-center font-bold dark:bg-slate-800" />
          </div>

          <Button type="submit" disabled={loading} className={cn("w-full h-16 text-white text-xl font-black rounded-3xl shadow-xl transition-all", role === 'merchant' ? "bg-blue-600 hover:bg-blue-700" : "bg-orange-500 hover:bg-orange-600")}>
            {loading ? <Loader2 className="animate-spin" /> : "إنشاء الحساب الآن"}
          </Button>
        </form>

        <div className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="h-px bg-slate-100 flex-1" />
            <span className="text-[10px] font-black text-slate-400 uppercase">أو التسجيل بواسطة</span>
            <div className="h-px bg-slate-100 flex-1" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Button onClick={() => handleSocialRegister('google')} variant="outline" className="h-14 rounded-2xl border-2 font-bold gap-3 hover:bg-slate-50 shadow-sm">
              <VicksLogo className="w-5 h-5" /> 
              <span>Google</span>
            </Button>
            <Button onClick={() => handleSocialRegister('facebook')} variant="outline" className="h-14 rounded-2xl border-2 font-bold gap-3 hover:bg-slate-50 shadow-sm">
              <span className="w-5 h-5 bg-blue-600 text-white rounded-full flex items-center justify-center font-black text-xs">f</span> 
              <span>Facebook</span>
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
