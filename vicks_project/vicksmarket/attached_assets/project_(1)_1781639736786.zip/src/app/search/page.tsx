
"use client";

import React, { useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Search, Filter, MapPin, Loader2, Sparkles } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useFirestore, useCollection } from "@/firebase";
import { collection, query, where, limit, orderBy } from "firebase/firestore";
import { VicksProductCard } from "@/components/VicksProductCard";

const governorates = [
  "الكل", "القاهرة", "الجيزة", "الإسكندرية", "سوهاج", "أسيوط", "المنصورة", "طنطا", "الأقصر", "أسوان"
];

export default function SearchPage() {
  const router = useRouter();
  const db = useFirestore();
  const [searchTerm, setSearchTerm] = useState("");
  const [location, setLocation] = useState("الكل");
  const [category, setCategory] = useState("الكل");

  const searchQuery = useMemo(() => {
    let q = query(
      collection(db, "products"), 
      orderBy("isOriginal", "desc"), // أولوية الموثقين ذهبياً تظهر أولاً في البحث
      orderBy("createdAt", "desc"),
      limit(50)
    );
    
    if (location !== "الكل") {
      q = query(q, where("location", "==", location));
    }
    if (category !== "الكل") {
      q = query(q, where("category", "==", category));
    }
    
    return q;
  }, [db, location, category]);

  const { data: products, loading } = useCollection(searchQuery);

  const filteredProducts = useMemo(() => {
    if (!products) return [];
    if (!searchTerm.trim()) return products;
    return products.filter(p => 
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      p.description?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [products, searchTerm]);

  return (
    <div className="min-h-screen bg-[#F8F9FA] dark:bg-[#1A2332] p-4 text-right font-cairo" dir="rtl">
      <header className="flex items-center gap-3 mb-6">
        <button onClick={() => router.back()} className="w-10 h-10 bg-white dark:bg-slate-800 rounded-full shadow-sm flex items-center justify-center">
          <ArrowLeft className="w-5 h-5 rotate-180" />
        </button>
        <div className="flex-1 relative">
           <Input 
             value={searchTerm}
             onChange={(e) => setSearchTerm(e.target.value)}
             placeholder="ابحث عن ايفون، ملابس، سيارات..." 
             className="h-12 rounded-2xl border-2 border-orange-100 pr-12 font-bold dark:bg-slate-900" 
           />
           <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-orange-500" />
        </div>
      </header>

      <section className="bg-white dark:bg-slate-800 p-4 rounded-3xl shadow-sm mb-6 flex flex-wrap gap-3 items-center">
        <div className="flex items-center gap-2 text-xs font-black text-slate-400">
           <Filter className="w-4 h-4" /> فلتر ذكي:
        </div>
        
        <Select value={location} onValueChange={setLocation}>
          <SelectTrigger className="w-[120px] h-9 rounded-xl border-orange-50 dark:bg-slate-900 text-[10px] font-bold">
            <MapPin className="w-3 h-3 ml-1 text-orange-500" />
            <SelectValue placeholder="المحافظة" />
          </SelectTrigger>
          <SelectContent>
            {governorates.map(gov => <SelectItem key={gov} value={gov}>{gov}</SelectItem>)}
          </SelectContent>
        </Select>

        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="w-[120px] h-9 rounded-xl border-orange-50 dark:bg-slate-900 text-[10px] font-bold">
            <Sparkles className="w-3 h-3 ml-1 text-blue-500" />
            <SelectValue placeholder="القسم" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="الكل">كل الأقسام</SelectItem>
            <SelectItem value="سوبر ماركت">سوبر ماركت</SelectItem>
            <SelectItem value="إلكترونيات">إلكترونيات</SelectItem>
            <SelectItem value="ملابس">ملابس</SelectItem>
            <SelectItem value="جمال وعناية">جمال وعناية</SelectItem>
          </SelectContent>
        </Select>
      </section>

      <main>
        {loading ? (
          <div className="flex justify-center py-20"><Loader2 className="animate-spin text-orange-500" /></div>
        ) : filteredProducts.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {filteredProducts.map(p => (
              <VicksProductCard 
                key={p.id}
                id={p.id}
                name={p.name}
                price={p.price.toString()}
                image={p.image}
                seller={p.seller}
                location={p.location}
                views={p.views}
                isVerified={p.isOriginal}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 space-y-4">
             <div className="w-20 h-20 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto">
               <Search className="w-10 h-10 text-slate-300" />
             </div>
             <p className="font-black text-slate-400">لم نجد أي نتائج تطابق بحثك يا ملك.</p>
          </div>
        )}
      </main>
    </div>
  );
}
