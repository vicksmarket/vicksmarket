
"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { 
  ArrowLeft, Crown, Coins, Video, Loader2, Zap, Wallet, Check, Star 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { VicksLogo } from "@/components/VicksLogo";
import { useUser, useFirestore, useDoc } from "@/firebase";
import { doc, updateDoc, increment, serverTimestamp } from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";
import { VicksPWAInstall } from "@/components/VicksPWAInstall";
import { cn } from "@/lib/utils";

const plans = [
  {
    id: "silver",
    name: "الباقة الفضية (Silver)",
    price: 200,
    icon: <Star className="w-6 h-6 text-slate-400" />,
    color: "border-slate-300 bg-slate-50 dark:bg-slate-900/40",
    features: [
      "نشر حتى 50 منتجاً",
      "رفع فيديوهات REELS (منتج واحد شهرياً)",
      "أولوية ظهور متوسطة",
      "دعم فني سريع"
    ],
    maxProducts: 50
  },
  {
    id: "gold",
    name: "الباقة الذهبية الملكية",
    price: 600,
    icon: <Crown className="w-8 h-8 text-yellow-500" />,
    color: "border-yellow-400 bg-yellow-50 dark:bg-yellow-950/20",
    features: [
      "نشر منتجات غير محدود (Infinity)",
      "نشر فيديوهات REELS غير محدود",
      "شارة التوثيق الذهبية مجاناً",
      "أولوية ظهور مطلقة في البحث",
      "دعم فني خاص VIP"
    ],
    maxProducts: 999999
  }
];

export default function VIPPage() {
  const router = useRouter();
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [cooldown, setCooldown] = useState(0);

  const userProfileRef = user ? doc(db, "users", user.uid) : null;
  const { data: profile } = useDoc(userProfileRef);

  const isBanned = profile?.status === 'banned' || profile?.status === 'suspended';

  useEffect(() => {
    if (profile?.lastAdWatch) {
      const lastWatch = profile.lastAdWatch.toMillis ? profile.lastAdWatch.toMillis() : new Date(profile.lastAdWatch).getTime();
      const now = Date.now();
      const diff = now - lastWatch;
      const cooldownPeriod = 5 * 60 * 1000;
      if (diff < cooldownPeriod) setCooldown(Math.ceil((cooldownPeriod - diff) / 1000));
    }
  }, [profile]);

  useEffect(() => {
    if (cooldown > 0) {
      const timer = setInterval(() => setCooldown((prev) => (prev > 0 ? prev - 1 : 0)), 1000);
      return () => clearInterval(timer);
    }
  }, [cooldown]);

  const addPointsAfterAd = async () => {
    if (!user || !userProfileRef) return;
    if (isBanned) {
      toast({ variant: "destructive", title: "تعذر التحميل", description: "فشل الاتصال بسيرفر الإعلانات." });
      return;
    }
    
    setIsProcessing(true);
    toast({ title: "جاري تشغيل الإعلان...", description: "شاهد الفيديو للنهاية للحصول على المكافأة." });
    
    setTimeout(async () => {
      updateDoc(userProfileRef, {
        points: increment(25),
        lastAdWatch: serverTimestamp()
      }).then(() => {
        toast({ title: "مبروك! +25 نقطة", description: "تمت إضافة المكافأة لحسابك." });
        setCooldown(300);
      }).finally(() => setIsProcessing(false));
    }, 2000);
  };

  const handleSubscribe = async (plan: typeof plans[0]) => {
    if (!user) { router.push('/login'); return; }
    if (isBanned) {
      toast({ variant: "destructive", title: "عملية مرفوضة", description: "حسابك غير مخول للقيام بهذه العملية حالياً." });
      return;
    }

    const userPoints = profile?.points || 0;
    if (userPoints < plan.price) {
      toast({ variant: "destructive", title: "نقاط غير كافية", description: `تحتاج إلى ${plan.price - userPoints} نقطة إضافية لترقية الباقة.` });
      return;
    }

    setIsProcessing(true);
    updateDoc(userProfileRef!, {
      points: increment(-plan.price),
      subscriptionPlan: plan.id,
      maxProducts: plan.maxProducts,
      isVerified: plan.id === 'gold' ? true : profile?.isVerified,
      verificationType: plan.id === 'gold' ? 'gold' : profile?.verificationType,
      role: "merchant"
    }).then(() => {
      toast({ title: "تم تفعيل الباقة بنجاح!", description: `مبروك! لقد أصبحت مشتركاً في ${plan.name}.` });
    }).finally(() => setIsProcessing(false));
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] dark:bg-[#1A2332] p-4 text-right font-cairo pb-20" dir="rtl">
      <header className="flex flex-col gap-4 px-4 py-4 bg-white dark:bg-[#1A2332] border-b sticky top-0 z-50 shadow-sm">
        <div className="flex items-center justify-between">
          <button onClick={() => router.push('/')} className="w-10 h-10 flex items-center justify-center bg-slate-100 dark:bg-slate-800 rounded-full">
            <ArrowLeft className="w-5 h-5 rotate-180" />
          </button>
          <div className="flex items-center gap-2">
            <span className="font-black text-slate-800 dark:text-white uppercase tracking-tighter">VICKS VIP</span>
            <VicksLogo className="w-8 h-8" />
          </div>
        </div>
      </header>

      <div className={cn("mx-4 mt-6 p-6 rounded-[2.5rem] shadow-2xl text-white relative overflow-hidden border-b-8 transition-all", profile?.subscriptionPlan === 'gold' ? "bg-gradient-to-br from-yellow-600 to-yellow-400 border-yellow-300" : "bg-gradient-to-br from-[#1A2332] to-[#252D3D] border-orange-500")}>
        <div className="absolute top-0 left-0 p-8 opacity-10"><Wallet className="w-32 h-32 rotate-12 text-white" /></div>
        <div className="relative z-10 flex items-center justify-between">
          <div className="flex items-center gap-4">
             <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg", profile?.subscriptionPlan === 'gold' ? "bg-white text-yellow-600" : "bg-orange-500 text-white")}>
               {profile?.subscriptionPlan === 'gold' ? <Crown className="w-8 h-8" /> : <Coins className="w-8 h-8" />}
             </div>
             <div className="flex flex-col">
               <span className="text-[10px] font-black opacity-80 uppercase tracking-widest">رصيد النقاط {isBanned && "(مجمد)"}</span>
               <span className="text-4xl font-black">{profile?.points || 0}</span>
               <div className="mt-1 flex items-center gap-2">
                 <span className="text-[8px] font-bold bg-white/20 px-2 py-0.5 rounded-full">الباقة: {profile?.subscriptionPlan === 'gold' ? 'الذهبية' : (profile?.subscriptionPlan === 'silver' ? 'الفضية' : 'المجانية')}</span>
                 <span className="text-[8px] font-bold">المنتجات: {profile?.productsCount || 0} / {profile?.maxProducts || 5}</span>
               </div>
             </div>
          </div>
        </div>
      </div>

      <main className="px-4 py-8 space-y-10">
        <section className="bg-orange-50 dark:bg-orange-950/10 p-6 rounded-[2.5rem] border-2 border-dashed border-orange-200">
           <h2 className="text-lg font-black text-orange-600 flex items-center gap-3 mb-2"><Zap className="w-6 h-6 text-orange-500 fill-orange-500" /> شحن النقاط كاش</h2>
           <p className="text-[10px] font-bold text-slate-500 mb-4">نظام الدفع: <span className="text-emerald-600 font-black">100 نقطة = 100 جنيه مصري</span></p>
           <Button onClick={() => isBanned ? toast({title: "خطأ", description: "الخدمة معطلة مؤقتاً."}) : router.push('/owner-chat')} className="w-full bg-slate-900 text-white rounded-2xl h-12 font-black shadow-lg">اطلب شحن نقاط كاش الآن</Button>
        </section>

        <section className="space-y-4">
          <h2 className="text-lg font-black text-orange-600 flex items-center gap-2 border-r-4 border-orange-500 pr-2"><Video className="w-6 h-6" /> جمع النقاط مجاناً</h2>
          <div className="bg-white dark:bg-slate-800 p-6 rounded-[2.5rem] border shadow-sm">
            <div className="flex items-center justify-between gap-4">
              <div className="flex-1">
                <p className="font-black text-sm">شاهد إعلان المكافأة</p>
                <p className="text-[9px] text-slate-400 font-bold">احصل على 25 نقطة فوراً</p>
              </div>
              <Button onClick={addPointsAfterAd} disabled={isProcessing || cooldown > 0} className="min-w-[100px] h-12 rounded-2xl font-black bg-orange-500 hover:bg-orange-600 text-white">
                {isProcessing ? <Loader2 className="animate-spin w-4 h-4" /> : (cooldown > 0 ? `${cooldown}ث` : "مشاهدة")}
              </Button>
            </div>
          </div>
        </section>

        <section className="space-y-6">
          <h2 className="text-lg font-black text-blue-600 flex items-center gap-2 border-r-4 border-blue-500 pr-2"><Crown className="w-6 h-6 text-yellow-500" /> باقات التوثيق والحصص</h2>
          
          <div className="grid gap-6">
            {plans.map((plan) => (
              <div key={plan.id} className={cn("p-6 rounded-[3rem] border-2 shadow-xl space-y-5 transition-all group", plan.color)}>
                 <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                       <div className="w-12 h-12 rounded-2xl bg-white dark:bg-slate-800 flex items-center justify-center shadow-sm">
                          {plan.icon}
                       </div>
                       <div>
                          <h3 className="font-black text-lg">{plan.name}</h3>
                          <p className="text-[9px] text-slate-400 font-bold">حصة منتجات: {plan.maxProducts === 999999 ? 'غير محدودة' : plan.maxProducts}</p>
                       </div>
                    </div>
                    <div className="flex items-center gap-1 text-orange-500 font-black"><span className="text-2xl">{plan.price}</span><Coins className="w-4 h-4" /></div>
                 </div>
                 <ul className="space-y-2 px-2">
                    {plan.features.map((feat, i) => (
                      <li key={i} className="flex items-center gap-2 text-[10px] font-black text-slate-600 dark:text-slate-300">
                        <Check className="w-3.5 h-3.5 text-emerald-500" /> {feat}
                      </li>
                    ))}
                 </ul>
                 <Button 
                   onClick={() => handleSubscribe(plan)} 
                   disabled={isProcessing || profile?.subscriptionPlan === plan.id} 
                   className={cn("w-full h-12 rounded-2xl font-black text-white shadow-lg transition-all active:scale-95", plan.id === 'gold' ? "bg-yellow-500 hover:bg-yellow-600" : "bg-slate-900 hover:bg-black")}
                 >
                    {profile?.subscriptionPlan === plan.id ? "الباقة مفعلة حالياً ✅" : "تفعيل الباقة الآن"}
                 </Button>
              </div>
            ))}
          </div>
        </section>
      </main>
      
      <div className="px-4">
        <VicksPWAInstall />
      </div>
    </div>
  );
}
