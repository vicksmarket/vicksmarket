
"use client";

import { useEffect } from 'react';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';
import { useToast } from '@/hooks/use-toast';

/**
 * @fileOverview مستمع مركزي لأخطاء صلاحيات Firebase Security Rules.
 * يقوم بعرض تنبيهات سياقية للمطورين أثناء فحص الموقع.
 */
export function FirebaseErrorListener() {
  const { toast } = useToast();

  useEffect(() => {
    const handleError = (error: FirestorePermissionError) => {
      console.error('Firestore Security Error:', error.context);
      toast({
        variant: "destructive",
        title: "خطأ في الصلاحيات (Security Rules)",
        description: `العملية: ${error.context.operation} على المسار: ${error.context.path}. يرجى مراجعة القواعد.`,
      });
    };

    errorEmitter.on('permission-error', handleError);
    return () => {
      errorEmitter.off('permission-error', handleError);
    };
  }, [toast]);

  return null;
}
