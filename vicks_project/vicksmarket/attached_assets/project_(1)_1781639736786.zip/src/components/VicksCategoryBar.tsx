
"use client";

import React, { useState, useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";
import { Sparkles } from "lucide-react";
import { useUser, useFirestore, useDoc } from "@/firebase";
import { doc } from "firebase/firestore";
import { cn } from "@/lib/utils";

const malls = [
  { id: "carrefour", name: "Carrefour", route: "/malls/carrefour", color: "border-blue-600 text-blue-600" },
  { id: "arabia", name: "Mall of Arabia", route: "/malls/arabia", color: "border-emerald-600 text-emerald-600" },
  { id: "titan", name: "Titan Mall", route: "/malls/titan", color: "border-slate-800 text-slate-800" },
  { id: "capital", name: "Capital", route: "/malls/capital", color: "border-orange-600 text-orange-600" },
  { id: "cleopatra", name: "Cleopatra", route: "/malls/cleopatra", color: "border-amber-700 text-amber-700" },
];

const categories = [
  { name: "الكل", icon: "💎", route: "/" },
  { name: "عروض", icon: "🔥", route: "/offers" },
  { name: "سوبر ماركت", icon: "🏪", route: "/supermarket" },
  { name: "أدوات منزلية", icon: "🏠", route: "/home-tools" },
  { name: "مستعمل", icon: "♻️", route: "/used" },
  { name: "جمال وعناية", icon: "🌿", route: "/beauty" },
  { name: "ملابس", icon: "👕", route: "/clothes" },
  { name: "إلكترونيات", icon: "📱", route: "/electronics" },
];

const ADMIN_EMAILS = ["mom1113694362@gmail.com", "vicksmarket@gmail.com"];

interface CategoryBarProps {
  onCategoryChange?: (category: string) => void;
  activeCategory?: string;
}

export function VicksCategoryBar({ onCategoryChange, activeCategory }: CategoryBarProps) {
  const router = useRouter();
  const pathname = usePathname();
  const { user } = useUser();
  const db = useFirestore();
  const [isAdminLocal, setIsAdminLocal] = useState(false);
  const [tempRole, setTempRole] = useState<string | null>(null);

  const userProfileRef = user ? doc(db, "users", user.uid) : null;
  const { data: profile } = useDoc(userProfileRef);

  useEffect(() => {
    const mockMode = localStorage.getItem('vicks_admin_mode');
    if (mockMode === 'active') setIsAdminLocal(true);
    setTempRole(localStorage.getItem('vicks_temp_role'));
  }, []);

  const isAdmin = !tempRole && (isAdminLocal || (user?.email && ADMIN_EMAILS.includes(user.email)));
  const canSeeVIP = tempRole === 'merchant' || (profile?.role === 'merchant' || isAdmin);

  const handleCategoryClick = (cat: { name: string; route: string }) => {
    router.push(cat.route);
    if (onCategoryChange) {
      onCategoryChange(cat.name);
    }
  };

  return (
    <div className="bg-white dark:bg-[#1A2332] py-2 transition-colors duration-300 space-y-1.5 border-b dark:border-slate-800">
      
      {/* 1. شريط الفلاتر السريعة (Filter Tabs) - مصغر */}
      <div className="flex items-center justify-start px-4 gap-1.5 no-scrollbar overflow-x-auto py-1">
        {categories.map((cat) => {
          const isActive = activeCategory === cat.name || (pathname === cat.route && !pathname.startsWith('/malls'));
          return (
            <button
              key={cat.name}
              onClick={() => handleCategoryClick(cat)}
              className={cn(
                "flex items-center gap-1 px-3 py-1.5 rounded-full whitespace-nowrap transition-all border-2 text-[10px] font-black",
                isActive 
                ? "bg-orange-500 border-orange-500 text-white shadow-sm scale-105" 
                : "bg-white dark:bg-[#252D3D] border-slate-50 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:border-orange-100"
              )}
            >
               <span>{cat.name}</span>
               {cat.icon && <span className="text-[11px]">{cat.icon}</span>}
            </button>
          );
        })}
      </div>

      {/* 2. شريط المولات - ملتصق ومصغر ومحدد بالألوان */}
      <div className="flex items-center justify-start px-4 gap-1.5 no-scrollbar overflow-x-auto py-1">
        {malls.map((mall) => {
          const isActive = pathname === mall.route;
          return (
            <button
              key={mall.id}
              onClick={() => router.push(mall.route)}
              className={cn(
                "px-3 py-1.5 rounded-full border-2 transition-all whitespace-nowrap font-black text-[9px] uppercase tracking-tighter",
                isActive 
                ? "bg-slate-900 border-slate-900 text-white scale-105" 
                : cn("bg-white dark:bg-slate-800 text-slate-500 hover:bg-slate-50", mall.color)
              )}
            >
              {mall.name}
            </button>
          );
        })}
        
        {/* زر VIP مصغر في نهاية الشريط لسهولة الوصول */}
        {canSeeVIP && (
           <button 
             className="px-3 py-1.5 bg-yellow-400 text-black border-2 border-yellow-500 rounded-full text-[9px] font-black flex items-center gap-1 shadow-sm"
             onClick={() => router.push('/vip')}
           >
             <Sparkles className="w-2.5 h-2.5" /> VIP
           </button>
        )}
      </div>
    </div>
  );
}
