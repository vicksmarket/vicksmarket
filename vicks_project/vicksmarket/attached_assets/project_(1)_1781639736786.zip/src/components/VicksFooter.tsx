
"use client";

import React from "react";
import Link from "next/link";
import { ShieldAlert, MessageCircle, Info } from "lucide-react";
import { VicksLogo } from "./VicksLogo";
import { useRouter } from "next/navigation";
import { useUser } from "@/firebase";

export function VicksFooter() {
  const router = useRouter();
  const { user } = useUser();

  const handleChatWithOwner = () => {
    if (!user) {
      router.push('/login');
      return;
    }
    router.push('/owner-chat');
  };

  return (
    <footer className="bg-white dark:bg-[#1A2332] border-t dark:border-slate-800 mt-10 pt-10 pb-24 px-6 text-right font-cairo" dir="rtl">
      <div className="max-w-4xl mx-auto space-y-10">
        <div className="flex flex-col items-center gap-4 text-center">
          <VicksLogo className="w-16 h-16 opacity-50 grayscale hover:grayscale-0 transition-all" />
          <h3 className="font-black text-lg dark:text-white uppercase tracking-tighter">VICKS MARKET</h3>
          <p className="text-xs text-slate-400 font-bold max-w-xs">سوقك الموثق والآمن لبيع وشراء كل احتياجاتك بذكاء.</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
          <div className="space-y-4">
            <h4 className="font-black text-orange-500 text-xs uppercase">المتجر</h4>
            <ul className="space-y-2 text-xs font-bold text-slate-500 dark:text-slate-400">
              <li><Link href="/offers">العروض اليومية</Link></li>
              <li><Link href="/vip">خدمات VIP</Link></li>
              <li><Link href="/faq">الأسئلة الشائعة</Link></li>
            </ul>
          </div>
          <div className="space-y-4">
            <h4 className="font-black text-blue-500 text-xs uppercase">قانوني</h4>
            <ul className="space-y-2 text-xs font-bold text-slate-500 dark:text-slate-400">
              <li><Link href="/terms">الشروط والأحكام</Link></li>
              <li><Link href="/verify-email">تحقق الحساب</Link></li>
            </ul>
          </div>
          <div className="col-span-2 md:col-span-1 space-y-4">
            <h4 className="font-black text-red-500 text-xs uppercase">تواصل</h4>
            <button 
              onClick={handleChatWithOwner}
              className="flex items-center gap-2 bg-slate-900 text-white px-4 py-2 rounded-xl text-[10px] font-black shadow-lg hover:bg-black transition-all"
            >
              <MessageCircle className="w-4 h-4 text-orange-500" />
              تحدث مع صاحب المتجر
            </button>
          </div>
        </div>

        <div className="bg-slate-50 dark:bg-slate-800/50 p-6 rounded-[2.5rem] border-2 border-dashed border-slate-200 dark:border-slate-700">
          <div className="flex items-center gap-2 mb-2 text-red-500">
            <ShieldAlert className="w-5 h-5" />
            <h4 className="font-black text-xs">إخلاء مسؤولية قانوني</h4>
          </div>
          <p className="text-[10px] font-bold text-slate-500 dark:text-slate-400 leading-relaxed">
            Vicks Market هو منصة للوساطة والربط بين البائع والمشتري فقط. إدارة الموقع غير مسؤولة عن جودة أو قانونية المنتجات المعروضة من قبل المستخدمين. يرجى دائماً فحص المنتج في مكان عام وآمن قبل إتمام أي عملية دفع أو استلام.
          </p>
        </div>

        <div className="text-center pt-6 border-t dark:border-slate-800">
          <p className="text-[10px] font-black text-slate-300 uppercase">© {new Date().getFullYear()} VICKS MARKET . ALL RIGHTS RESERVED BY MOM</p>
        </div>
      </div>
    </footer>
  );
}
