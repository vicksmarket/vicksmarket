"use client";

import React, { useState, useEffect, Suspense } from "react";
import { Search, User, ShieldCheck, Sun, Moon, Camera, Plus, Crown, LayoutGrid, List, Sparkles, LayoutDashboard } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { useRouter, usePathname, useSearchParams } from "next/navigation";
import { VicksLogo } from "./VicksLogo";
import { cn } from "@/lib/utils";
import { useUser, useFirestore, useDoc } from "@/firebase";
import { doc } from "firebase/firestore";
import { translations, Language } from "@/lib/translations";
import { VisualSearchDialog } from "@/components/VicksVisualSearch";

const ADMIN_EMAILS = ["mom1113694362@gmail.com", "vicksmarket@gmail.com"];

function HeaderControls() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const { user } = useUser();
  const db = useFirestore();
  const [showSearch, setShowSearch] = useState(false);
  const [isDark, setIsDark] = useState(false);
  const [lang, setLang] = useState<Language>('ar');
  const [isAdminLocal, setIsAdminLocal] = useState(false);
  const [tempRole, setTempRole] = useState<string | null>(null);

  const { data: profile } = useDoc(user ? doc(db, "users", user.uid) : null);
  const viewMode = searchParams.get('view') || 'grid';
  const t = translations[lang];

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
      document.documentElement.classList.add('dark');
      setIsDark(true);
    }
    const savedLang = localStorage.getItem('vicks_lang') as Language;
    if (savedLang) setLang(savedLang);
    
    const mockMode = localStorage.getItem('vicks_admin_mode');
    if (mockMode === 'active') setIsAdminLocal(true);
    setTempRole(localStorage.getItem('vicks_temp_role'));
  }, [profile]);

  const toggleDarkMode = () => {
    const newTheme = isDark ? 'light' : 'dark';
    document.documentElement.classList.toggle('dark');
    localStorage.setItem('theme', newTheme);
    setIsDark(!isDark);
  };

  const toggleView = () => {
    const newView = viewMode === 'grid' ? 'list' : 'grid';
    const params = new URLSearchParams(searchParams.toString());
    params.set('view', newView);
    router.push(`${pathname}?${params.toString()}`);
  };

  const isActuallyAdmin = !tempRole && (isAdminLocal || (user?.email && ADMIN_EMAILS.includes(user.email)));
  const isMerchant = profile?.role === 'merchant' || isActuallyAdmin;

  return (
    <>
      {tempRole && profile?.unique_id === "1000000000" && (
        <div className="bg-orange-50 text-white text-[8px] font-black text-center py-1 uppercase tracking-widest flex items-center justify-center gap-2 mb-1 rounded-full">
           <Crown className="w-2 h-2" /> وضع معاينة الـ {tempRole === 'merchant' ? 'تاجر' : 'زبون'} نشط <Crown className="w-2 h-2" />
        </div>
      )}
      
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="bg-slate-50 dark:bg-slate-800 rounded-full w-8 h-8" onClick={toggleDarkMode}>
            {isDark ? <Sun className="w-3.5 h-3.5 text-yellow-400" /> : <Moon className="w-3.5 h-3.5 text-slate-500" />}
          </Button>
          <Button variant="ghost" size="icon" className="bg-slate-50 dark:bg-slate-800 rounded-full w-8 h-8" onClick={() => setShowSearch(!showSearch)}>
            <Search className="w-3.5 h-3.5 text-orange-500" />
          </Button>
          
          <div className="h-4 w-px bg-slate-200 dark:bg-slate-700 mx-0.5" />

          <button className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center text-white shadow-lg" onClick={toggleView}>
            {viewMode === 'grid' ? <List className="w-4 h-4" /> : <LayoutGrid className="w-4 h-4" />}
          </button>

          <Button variant="ghost" size="icon" onClick={() => router.push(user ? '/profile' : '/login')} className="bg-slate-50 dark:bg-slate-800 rounded-full w-8 h-8 ml-1">
            {isActuallyAdmin ? <ShieldCheck className="w-3.5 h-3.5 text-orange-500" /> : <User className="w-3.5 h-3.5" />}
          </Button>

          {isMerchant && (
            <button className="hidden md:flex items-center gap-1 px-3 py-1.5 bg-slate-900 rounded-full text-[9px] font-black text-white ml-2" onClick={() => router.push('/merchant/studio')}>
              <LayoutDashboard className="w-3 h-3 text-orange-500" /> <span>STUDIO</span>
            </button>
          )}
        </div>

        <Link href="/" className="flex items-center gap-2">
          <div className={cn("flex flex-col items-end")}>
            <span className="text-sm font-black tracking-tighter text-[#1A2332] dark:text-white uppercase leading-none">{t.title}</span>
            <span className="text-[8px] font-bold text-orange-500">{t.subtitle}</span>
          </div>
          <div className="w-7 h-7"><VicksLogo className="w-full h-full" /></div>
        </Link>
      </div>

      <div className={cn("overflow-hidden transition-all duration-300", showSearch ? "max-h-24 mt-2 opacity-100" : "max-h-0 mt-0 opacity-0")}>
        <div className="flex items-center gap-2" dir="rtl">
          <div className="relative flex-1">
            <Input className="w-full h-9 rounded-full border-2 border-orange-100 pr-9 text-xs dark:bg-slate-800 text-right font-bold" placeholder={t.search} />
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-orange-500" />
          </div>
          <div className="flex items-center gap-1">
            <VisualSearchDialog mode="upload"><Button variant="ghost" size="icon" className="w-8 h-8 bg-slate-50 rounded-full text-blue-500"><Plus className="w-4 h-4" /></Button></VisualSearchDialog>
            <VisualSearchDialog mode="camera"><Button variant="ghost" size="icon" className="w-8 h-8 bg-slate-50 rounded-full text-orange-500"><Camera className="w-4 h-4" /></Button></VisualSearchDialog>
          </div>
        </div>
      </div>
    </>
  );
}

export function VicksHeader() {
  return (
    <header className="w-full bg-white dark:bg-[#1A2332] px-4 py-2 sticky top-0 z-50 shadow-sm border-b dark:border-slate-800">
      <Suspense fallback={<div className="h-10 animate-pulse bg-slate-50 rounded-full" />}>
        <HeaderControls />
      </Suspense>
    </header>
  );
}
