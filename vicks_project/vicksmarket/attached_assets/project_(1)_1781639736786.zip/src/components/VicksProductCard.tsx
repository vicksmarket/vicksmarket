"use client";

import React, { useState, useMemo, useEffect } from "react";
import Image from "next/image";
import { Star, BadgeCheck, Heart, MessageCircle, Send, User, Loader2, SendHorizontal, CircleHelp } from "lucide-react";
import { Card } from "@/components/ui/card";
import { useRouter } from "next/navigation";
import { cn } from "@/lib/utils";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { useUser, useFirestore, useCollection, useDoc } from "@/firebase";
import { collection, query, orderBy, limit, doc, setDoc, updateDoc, increment, serverTimestamp } from "firebase/firestore";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface ProductCardProps {
  id: string;
  name: string;
  price: string;
  image: string;
  seller: string;
  sellerId: string;
  sellerImage?: string;
  rating?: number;
  isVerified?: boolean;
  isGold?: boolean;
  phone?: string;
  telegram?: string;
  description?: string;
}

/**
 * @fileOverview كارت المنتج النهائي بالترتيب الهندسي المعتمد 1.0.
 * الترتيب: [التاجر فوق ⬅️ الصورة 220px ⬅️ السعر والنجوم ⬅️ الاسم ⬅️ الأزرار].
 */
export function VicksProductCard({ 
  id, name, price, image, seller, sellerId, sellerImage, 
  rating = 5, isVerified = true, isGold = false, 
  phone = "201113694362", telegram, description
}: ProductCardProps) {
  const router = useRouter();
  const { user } = useUser();
  const db = useFirestore();
  
  const [isLiked, setIsLiked] = useState(false);
  const [tempRating, setTempRating] = useState(0);
  const [commentText, setCommentText] = useState("");

  const handleWhatsApp = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    const text = `أهلاً يا ملك، أنا مهتم بمنتج "${name}"\n${window.location.origin}/product/${id}`;
    window.open(`https://wa.me/${phone?.replace(/\D/g, '') || '201113694362'}?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handleTelegram = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    window.open(`https://t.me/${telegram || 'vicks_market'}`, '_blank');
  };

  return (
    <Card className="overflow-hidden border-none shadow-none bg-white dark:bg-[#252D3D] rounded-none w-full min-w-[170px] max-w-[190px] m-0 p-0 flex flex-col">
      
      {/* 1. هيدر التاجر (أعلى الكارت) - RTL */}
      <div 
        className="flex items-center gap-2 px-3 py-2 bg-white dark:bg-[#252D3D] cursor-pointer" 
        dir="rtl" 
        onClick={() => router.push(`/merchant-profile/${sellerId}`)}
      >
         <div className="w-7 h-7 rounded-full bg-slate-100 overflow-hidden flex items-center justify-center border-2 border-white shadow-sm">
           {sellerImage ? <img src={sellerImage} className="w-full h-full object-cover" alt={seller} /> : <User className="w-4 h-4 text-slate-400" />}
         </div>
         <div className="flex items-center gap-1 truncate">
           <p className="text-[11px] font-black text-slate-800 dark:text-slate-100 truncate">{seller}</p>
           {isVerified && <BadgeCheck className={cn("w-4 h-4", isGold ? "text-yellow-500" : "text-blue-500")} />}
         </div>
      </div>

      {/* 2. صورة المنتج (ارتفاع ثابت + انحناء سفلي) */}
      <div className="relative w-full h-[220px] overflow-hidden bg-white dark:bg-slate-800 border-b dark:border-slate-700">
        <Image src={image} alt={name} fill className="object-contain p-2 rounded-b-[8px]" />
      </div>

      {/* 3. سطر السعر والنجوم */}
      <div className="px-2 pt-2 flex items-center justify-between gap-1" dir="rtl">
         <p className="text-orange-500 font-black text-lg tracking-tighter">
            {price.toString().replace(/\D/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
         </p>
         <div className="flex items-center gap-0.5">
            {[1, 2, 3, 4, 5].map((s) => (
              <Star key={s} className={cn("w-3 h-3", s <= (tempRating || rating) ? "text-yellow-400 fill-current" : "text-slate-200")} />
            ))}
         </div>
      </div>

      {/* 4. اسم المنتج */}
      <div className="px-2 pt-1 pb-2 h-7 overflow-hidden">
        <h3 className="font-black text-[10px] text-slate-800 dark:text-slate-100 line-clamp-1" dir="rtl">{name}</h3>
      </div>

      {/* 5. شريط الأزرار الخمسة (Action Bar) */}
      <div className="flex items-center justify-between px-2 pb-4 pt-1 border-t dark:border-slate-800 mt-auto" dir="rtl">
         <button onClick={handleWhatsApp} className="w-[34px] h-[34px] bg-[#25D366] text-white rounded-full flex items-center justify-center shadow-md active:scale-90"><MessageCircle className="w-5 h-5 fill-white" /></button>
         <button onClick={handleTelegram} className="w-[34px] h-[34px] bg-[#0088cc] text-white rounded-full flex items-center justify-center shadow-md active:scale-90"><Send className="w-5 h-5 fill-white" /></button>
         
         <Sheet>
            <SheetTrigger asChild><button className="w-[34px] h-[34px] rounded-full bg-slate-50 dark:bg-slate-800 border text-slate-500 flex items-center justify-center"><MessageCircle className="w-5 h-5" /></button></SheetTrigger>
            <SheetContent side="bottom" className="h-[70vh] rounded-t-[2.5rem] font-cairo text-right" dir="rtl">
               <SheetHeader className="p-4 border-b"><SheetTitle className="text-lg font-black">💬 تعليقات الملوك</SheetTitle></SheetHeader>
               <ScrollArea className="flex-1 p-4"><p className="text-center py-20 text-slate-400 text-sm font-bold">لا يوجد تعليقات بعد، كن الأول!</p></ScrollArea>
               <div className="p-4 border-t flex gap-2 mb-6">
                  <Input value={commentText} onChange={(e) => setCommentText(e.target.value)} placeholder="اكتب تعليقك..." className="h-10 rounded-xl" />
                  <Button className="w-10 h-10 bg-orange-500 rounded-full"><SendHorizontal className="w-4 h-4 rotate-180" /></Button>
               </div>
            </SheetContent>
         </Sheet>

         <Sheet>
            <SheetTrigger asChild><button className="w-[34px] h-[34px] rounded-full bg-slate-50 dark:bg-slate-800 border text-slate-500 flex items-center justify-center"><CircleHelp className="w-5 h-5" /></button></SheetTrigger>
            <SheetContent side="bottom" className="h-[80vh] rounded-t-[3rem] font-cairo text-right p-0" dir="rtl">
              <ScrollArea className="h-full p-6">
                 <div className="relative aspect-video rounded-2xl overflow-hidden mb-4"><Image src={image} alt={name} fill className="object-cover" /></div>
                 <h2 className="text-xl font-black mb-2">{name}</h2>
                 <p className="text-xs font-bold leading-loose text-slate-600 dark:text-slate-300">{description || "منتج عالي الجودة من فيكس ماركت."}</p>
                 <div className="flex gap-2 mt-8">
                    <Button onClick={() => handleWhatsApp()} className="flex-1 h-12 bg-[#25D366] text-white rounded-xl font-black">واتساب</Button>
                    <Button onClick={() => handleTelegram()} className="flex-1 h-12 bg-[#0088cc] text-white rounded-xl font-black">تليجرام</Button>
                 </div>
              </ScrollArea>
            </SheetContent>
         </Sheet>

         <button onClick={() => setIsLiked(!isLiked)} className={cn("w-[34px] h-[34px] rounded-full flex items-center justify-center shadow-md active:scale-125 transition-all border", isLiked ? "bg-red-50 text-red-500" : "bg-white dark:bg-slate-800 text-slate-400")}>
           <Heart className={cn("w-5 h-5", isLiked && "fill-current")} />
         </button>
      </div>
    </Card>
  );
}
