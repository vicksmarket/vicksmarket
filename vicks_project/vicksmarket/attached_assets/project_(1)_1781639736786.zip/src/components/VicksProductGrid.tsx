"use client";

import React, { useMemo } from "react";
import { VicksProductCard } from "./VicksProductCard";
import { useFirestore, useCollection } from "@/firebase";
import { collection, query, where, orderBy, limit } from "firebase/firestore";
import { Loader2 } from "lucide-react";
import { MOCK_PRODUCTS } from "@/app/lib/mock-data";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";

interface VicksProductGridProps {
  layout?: "grid" | "list";
  category?: string;
  products?: any[]; 
}

/**
 * @fileOverview شبكة عرض المنتجات مع دعم السحب الأفقي RTL للغة العربية.
 */
export function VicksProductGrid({ layout = "grid", category = "الكل", products: initialProducts }: VicksProductGridProps) {
  const db = useFirestore();

  const productsQuery = useMemo(() => {
    if (initialProducts) return null;
    const productsRef = collection(db, "products");
    
    let q;
    if (category === "الكل") {
      q = query(
        productsRef, 
        orderBy("isOriginal", "desc"), 
        orderBy("createdAt", "desc"), 
        limit(10)
      );
    } else {
      q = query(
        productsRef, 
        where("category", "==", category),
        orderBy("isOriginal", "desc"), 
        orderBy("createdAt", "desc"),
        limit(10)
      );
    }
    return q;
  }, [db, category, initialProducts]);

  const { data: fetchedProducts, loading } = useCollection(productsQuery);
  
  const products = useMemo(() => {
    if (initialProducts) return initialProducts.slice(0, 10);
    if (fetchedProducts && fetchedProducts.length > 0) return fetchedProducts;
    const mockSource = category === "الكل" ? MOCK_PRODUCTS : MOCK_PRODUCTS.filter(p => p.category === category);
    return mockSource.slice(0, 10);
  }, [initialProducts, fetchedProducts, category]);

  if (loading && !initialProducts) {
    return (
      <div className="flex justify-center items-center py-5">
        <Loader2 className="w-6 h-6 animate-spin text-orange-500" />
      </div>
    );
  }

  if (products.length === 0) return null;

  return (
    <div className="w-full border-none">
      {/* سحب أفقي يبدأ من اليمين RTL للغة العربية */}
      <ScrollArea className="w-full whitespace-nowrap" dir="rtl">
        <div className="flex px-0 gap-0">
          {products.map((product: any) => (
            <div key={product.id} className="inline-block p-0 m-0">
              <VicksProductCard 
                {...product}
                price={product.price.toString()}
              />
            </div>
          ))}
        </div>
        <ScrollBar orientation="horizontal" className="h-0 opacity-0" />
      </ScrollArea>
    </div>
  );
}
