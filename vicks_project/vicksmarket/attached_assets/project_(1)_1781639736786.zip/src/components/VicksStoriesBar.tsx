
"use client";

import React, { useState, useEffect, useMemo } from "react";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { VicksStoryViewer } from "./VicksStoryViewer";
import { useFirestore, useCollection, useUser } from "@/firebase";
import { collection, query, where, orderBy } from "firebase/firestore";
import { cn } from "@/lib/utils";
import { useRouter } from "next/navigation";

export function VicksStoriesBar() {
  const router = useRouter();
  const db = useFirestore();
  const { user } = useUser();
  const [viewedStories, setViewedStories] = useState<string[]>([]);
  const [activeStory, setActiveStory] = useState<any | null>(null);

  // جلب الاستوريز الحقيقية من فايربيز (التي لم تنتهِ صلاحيتها)
  const storiesQuery = useMemo(() => query(
    collection(db, "stories"),
    where("expiresAt", ">", Date.now()),
    orderBy("expiresAt", "asc")
  ), [db]);

  const { data: dbStories } = useCollection(storiesQuery);

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem("vicks_viewed_stories") || "[]");
    setViewedStories(saved);
  }, []);

  const handleStoryClick = (story: any) => {
    setActiveStory(story);
    if (!viewedStories.includes(story.id)) {
      const newList = [...viewedStories, story.id];
      setViewedStories(newList);
      localStorage.setItem("vicks_viewed_stories", JSON.stringify(newList));
    }
  };

  return (
    <div className="bg-white dark:bg-[#1A2332] py-4 border-b dark:border-slate-800">
      <ScrollArea className="w-full whitespace-nowrap" dir="rtl">
        <div className="flex px-4 gap-4">
          {/* دائرة إضافة استوري للمستخدم / التاجر */}
          <div 
            className="flex flex-col items-center gap-1 cursor-pointer"
            onClick={() => router.push('/merchant/studio')}
          >
             <div className="w-16 h-16 rounded-full bg-slate-100 dark:bg-slate-800 border-2 border-dashed border-orange-200 flex items-center justify-center text-orange-500">
                <span className="text-2xl font-black">+</span>
             </div>
             <span className="text-[9px] font-black text-slate-400 uppercase">نشر استوري</span>
          </div>

          {dbStories?.map((story: any) => (
            <div 
              key={story.id} 
              className="flex flex-col items-center gap-1 cursor-pointer group"
              onClick={() => handleStoryClick(story)}
            >
              <div className={cn(
                "p-[2.5px] rounded-full transition-all duration-500 shadow-sm",
                viewedStories.includes(story.id) 
                ? "bg-slate-200 dark:bg-slate-700" 
                : "bg-gradient-to-tr from-yellow-400 via-orange-500 to-pink-500 group-hover:scale-105"
              )}>
                <div className="w-16 h-16 rounded-full bg-white dark:bg-[#1A2332] p-[2px]">
                   <img 
                     src={story.sellerImage || `https://picsum.photos/seed/${story.sellerId}/200/200`} 
                     alt={story.sellerName} 
                     className="w-full h-full rounded-full object-cover border border-slate-100 dark:border-slate-800" 
                   />
                </div>
              </div>
              <span className="text-[9px] font-black dark:text-slate-200 truncate w-16 text-center">{story.sellerName}</span>
            </div>
          ))}
        </div>
        <ScrollBar orientation="horizontal" className="h-0 opacity-0" />
      </ScrollArea>

      {activeStory && (
        <VicksStoryViewer 
          story={activeStory} 
          isOpen={!!activeStory} 
          onClose={() => setActiveStory(null)} 
        />
      )}
    </div>
  );
}
