
"use client";

import React, { useEffect, useState, useRef } from "react";
import { useUser, useFirestore, useDoc } from "@/firebase";
import { doc, updateDoc } from "firebase/firestore";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Gavel } from "lucide-react";

/**
 * @fileOverview نظام مراقبة المخالفات والتوثيقات الصامت.
 * يقوم بفك الحظر تلقائياً وسحب التوثيقات المنتهية.
 */
export function ViolationChecker() {
  const { user } = useUser();
  const db = useFirestore();
  const userProfileRef = user ? doc(db, "users", user.uid) : null;
  const { data: profile } = useDoc(userProfileRef);
  const isUpdating = useRef(false);
  
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    if (profile && userProfileRef && !isUpdating.current) {
      const now = Date.now();

      // 1. فحص انتهاء الحظر
      if (profile.status === 'suspended' && profile.banExpiresAt) {
        const expires = new Date(profile.banExpiresAt).getTime();
        if (now > expires) {
          isUpdating.current = true;
          updateDoc(userProfileRef, { status: 'active', banExpiresAt: null }).finally(() => isUpdating.current = false);
        }
      }

      // 2. فحص انتهاء التوثيق
      if (profile.isVerified && profile.verificationExpiresAt) {
        const expires = new Date(profile.verificationExpiresAt).getTime();
        if (now > expires) {
          isUpdating.current = true;
          updateDoc(userProfileRef, { 
            isVerified: false, 
            verificationExpiresAt: null, 
            verificationType: null 
          }).finally(() => isUpdating.current = false);
        }
      }

      // إظهار التنبيه فقط إذا كان هناك رسالة تحذير جديدة
      if (profile.warningMessage) {
        setShowModal(true);
      }
    }
  }, [profile, userProfileRef]);

  const handleClose = async () => {
    if (userProfileRef) {
      await updateDoc(userProfileRef, { warningMessage: null });
    }
    setShowModal(false);
  };

  if (!profile) return null;

  return (
    <Dialog open={showModal} onOpenChange={() => {}}>
      <DialogContent className="rounded-[2.5rem] p-8 border-4 border-orange-500 text-right font-cairo" dir="rtl">
        <DialogHeader className="flex flex-col items-center gap-4">
           <div className="w-20 h-20 bg-orange-100 rounded-full flex items-center justify-center text-orange-600 shadow-inner">
             <AlertTriangle className="w-10 h-10" />
           </div>
           <DialogTitle className="text-2xl font-black text-orange-600">تنبيه إداري رسمي</DialogTitle>
           <DialogDescription className="text-slate-600 font-bold text-center leading-relaxed">
             {profile.warningMessage || "يرجى الالتزام بسياسات فيكس ماركت لضمان استمرار حسابك."}
           </DialogDescription>
        </DialogHeader>

        <div className="bg-slate-50 dark:bg-slate-900 p-5 rounded-3xl border-2 border-dashed border-orange-100 mt-4">
           <p className="text-[10px] font-black text-orange-500 uppercase flex items-center gap-2">
             <Gavel className="w-3 h-3" /> ملاحظة الإدارة
           </p>
           <p className="text-xs font-bold mt-1">المخالفة المسجلة: {profile.warningMessage}</p>
        </div>

        <DialogFooter className="mt-6">
          <Button onClick={handleClose} className="w-full h-14 bg-orange-500 hover:bg-orange-600 rounded-2xl font-black text-white shadow-lg">
            فهمت، سألتزم بالقوانين
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
