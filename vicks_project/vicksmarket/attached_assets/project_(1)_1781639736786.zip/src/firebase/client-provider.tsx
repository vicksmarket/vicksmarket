
'use client';

import { ReactNode, useEffect, useState } from 'react';
import { initializeFirebase } from './index';
import { FirebaseProvider } from './provider';
import { FirebaseApp } from 'firebase/app';
import { Firestore } from 'firebase/firestore';
import { Auth } from 'firebase/auth';
import { Loader2 } from 'lucide-react';

/**
 * @fileOverview مزود خدمات فايربيز لجهة العميل.
 * تم تعديله لضمان استقرار render السيرفر وعدم حظر المعاينة.
 */
export const FirebaseClientProvider = ({ children }: { children: ReactNode }) => {
  const [instances, setInstances] = useState<{
    firebaseApp: FirebaseApp;
    firestore: Firestore;
    auth: Auth;
  } | null>(null);

  useEffect(() => {
    try {
      const firebaseInstances = initializeFirebase();
      setInstances(firebaseInstances);
    } catch (error) {
      console.error("Firebase initialization failed:", error);
    }
  }, []);

  // إذا لم تكتمل التهيئة، نعرض محتوى الصفحة مع طبقة حماية لمنع انهيار الـ Preview
  if (!instances) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white dark:bg-[#1A2332]">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-10 h-10 animate-spin text-orange-500" />
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Vicks is warming up...</span>
        </div>
      </div>
    );
  }

  return (
    <FirebaseProvider
      firebaseApp={instances.firebaseApp}
      firestore={instances.firestore}
      auth={instances.auth}
    >
      {children}
    </FirebaseProvider>
  );
};
    