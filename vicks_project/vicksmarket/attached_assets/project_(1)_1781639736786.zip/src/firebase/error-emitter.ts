'use client';

/**
 * @fileOverview محرك أحداث متوافق مع المتصفح لضمان استقرار Next.js 15.
 * تم استبدال مكتبة node:events لضمان عدم انهيار السيرفر في المتصفح.
 */
type Listener = (...args: any[]) => void;

class BrowserEventEmitter {
  private events: { [key: string]: Listener[] } = {};

  on(event: string, listener: Listener) {
    if (!this.events[event]) this.events[event] = [];
    this.events[event].push(listener);
  }

  off(event: string, listener: Listener) {
    if (!this.events[event]) return;
    this.events[event] = this.events[event].filter(l => l !== listener);
  }

  emit(event: string, ...args: any[]) {
    if (!this.events[event]) return;
    this.events[event].forEach(l => l(...args));
  }
}

export const errorEmitter = new BrowserEventEmitter();
